<?php  return 'function elements_modsnippet_3($scriptProperties= array()) {
global $modx;
if (is_array($scriptProperties)) {
extract($scriptProperties, EXTR_SKIP);
}
/*
 * numFormat snippet
 * example: [[*price:num_format]]
 */

$input = floatval(str_replace(array(\' \',\',\'), array(\'\',\'.\'), $input));
return number_format($input,(floor($input) == $input ? 0 : 2),\'.\',\' \');
}
';