<?php /* Smarty version Smarty-3.0.4, created on 2013-06-26 11:55:28
         compiled from "/home/u316727/sonatel.ru/www/manager/templates/default/element/chunk/update.tpl" */ ?>
<?php /*%%SmartyHeaderCode:214396746951ca9e70761ad9-07040560%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5087332408a3c572d29ef6b59817da06d5cf2c6c' => 
    array (
      0 => '/home/u316727/sonatel.ru/www/manager/templates/default/element/chunk/update.tpl',
      1 => 1371823408,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '214396746951ca9e70761ad9-07040560',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="modx-panel-chunk-div"></div>
<?php echo $_smarty_tpl->getVariable('onChunkFormPrerender')->value;?>
