<?php /* Smarty version Smarty-3.0.4, created on 2013-06-26 11:48:25
         compiled from "/home/u316727/sonatel.ru/www/manager/templates/default/welcome.tpl" */ ?>
<?php /*%%SmartyHeaderCode:48433228951ca9cc96f2978-24053385%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b25db90da36857578844ebda3a82a470d2e51435' => 
    array (
      0 => '/home/u316727/sonatel.ru/www/manager/templates/default/welcome.tpl',
      1 => 1371823384,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '48433228951ca9cc96f2978-24053385',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="modx-panel-welcome-div"></div>

<div id="modx-dashboard" class="dashboard">
<?php echo $_smarty_tpl->getVariable('dashboard')->value;?>

</div>