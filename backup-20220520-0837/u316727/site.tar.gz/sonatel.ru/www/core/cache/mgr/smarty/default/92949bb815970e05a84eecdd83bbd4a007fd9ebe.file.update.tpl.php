<?php /* Smarty version Smarty-3.0.4, created on 2013-06-26 11:52:39
         compiled from "/home/u316727/sonatel.ru/www/manager/templates/default/resource/weblink/update.tpl" */ ?>
<?php /*%%SmartyHeaderCode:176798676951ca9dc7044a00-24806859%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92949bb815970e05a84eecdd83bbd4a007fd9ebe' => 
    array (
      0 => '/home/u316727/sonatel.ru/www/manager/templates/default/resource/weblink/update.tpl',
      1 => 1371823412,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '176798676951ca9dc7044a00-24806859',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="modx-panel-weblink-div"></div>
<div id="modx-resource-tvs-div" class="modx-resource-tab x-form-label-left x-panel"><?php echo $_smarty_tpl->getVariable('tvOutput')->value;?>
</div>

<?php echo $_smarty_tpl->getVariable('onDocFormPrerender')->value;?>

