<?php /* Smarty version Smarty-3.0.4, created on 2013-06-26 11:48:25
         compiled from "/home/u316727/sonatel.ru/www/manager/templates/default/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:200215200551ca9cc9723270-77578319%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd2206d63572f8f6852f6c1d55b9d7d1fc2a95518' => 
    array (
      0 => '/home/u316727/sonatel.ru/www/manager/templates/default/footer.tpl',
      1 => 1371823383,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '200215200551ca9cc9723270-77578319',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
        </div>
    </div> 
</div>

</body>
</html>