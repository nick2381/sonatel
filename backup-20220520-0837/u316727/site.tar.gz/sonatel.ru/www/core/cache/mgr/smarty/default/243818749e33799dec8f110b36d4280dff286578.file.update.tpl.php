<?php /* Smarty version Smarty-3.0.4, created on 2013-06-26 11:54:48
         compiled from "/home/u316727/sonatel.ru/www/manager/templates/default/element/template/update.tpl" */ ?>
<?php /*%%SmartyHeaderCode:63932306151ca9e483551b3-03867940%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '243818749e33799dec8f110b36d4280dff286578' => 
    array (
      0 => '/home/u316727/sonatel.ru/www/manager/templates/default/element/template/update.tpl',
      1 => 1371823409,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '63932306151ca9e483551b3-03867940',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="modx-panel-template-div"></div>
<?php echo $_smarty_tpl->getVariable('onTempFormPrerender')->value;?>
