<?php /* Smarty version Smarty-3.0.4, created on 2013-06-26 12:08:54
         compiled from "/home/u316727/sonatel.ru/www/manager/templates/default/context/update.tpl" */ ?>
<?php /*%%SmartyHeaderCode:103855338551caa1966e6a25-44592160%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fb6a3869590108741b268d5e7e5968ed2c337bac' => 
    array (
      0 => '/home/u316727/sonatel.ru/www/manager/templates/default/context/update.tpl',
      1 => 1371823392,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '103855338551caa1966e6a25-44592160',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="modx-panel-context-div"></div>