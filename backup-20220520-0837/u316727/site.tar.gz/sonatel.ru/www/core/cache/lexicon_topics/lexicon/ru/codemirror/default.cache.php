<?php  return array (
  'codemirror' => 'CodeMirror',
  'codemirror.search' => 'Search',
  'codemirror.replace' => 'Replace',
  'setting_codem.enable' => 'Enable CodeMirror',
  'setting_codem.enable_desc' => 'Set to enable or disable CodeMirror across your manager instance.',
);