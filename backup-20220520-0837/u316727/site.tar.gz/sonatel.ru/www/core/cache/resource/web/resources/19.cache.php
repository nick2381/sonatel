<?php  return array (
  'resourceClass' => 'modDocument',
  'resource' => 
  array (
    'id' => 19,
    'type' => 'document',
    'contentType' => 'text/html',
    'pagetitle' => '404 Ошибка',
    'longtitle' => '404 Ошибка',
    'description' => '404 Ошибка',
    'alias' => '404-oshibka',
    'link_attributes' => '',
    'published' => 1,
    'pub_date' => 0,
    'unpub_date' => 0,
    'parent' => 0,
    'isfolder' => 0,
    'introtext' => '404 Ошибка',
    'content' => '<p>404 Ошибка</p>',
    'richtext' => 1,
    'template' => 4,
    'menuindex' => 6,
    'searchable' => 1,
    'cacheable' => 1,
    'createdby' => 1,
    'createdon' => 1367261916,
    'editedby' => 1,
    'editedon' => 1367262705,
    'deleted' => 0,
    'deletedon' => 0,
    'deletedby' => 0,
    'publishedon' => 1367261880,
    'publishedby' => 1,
    'menutitle' => '',
    'donthit' => 0,
    'privateweb' => 0,
    'privatemgr' => 0,
    'content_dispo' => 0,
    'hidemenu' => 1,
    'class_key' => 'modDocument',
    'context_key' => 'web',
    'content_type' => 1,
    'uri' => '404-oshibka.html',
    'uri_override' => 0,
    'hide_children_in_tree' => 0,
    'show_in_tree' => 1,
    'properties' => NULL,
    '_content' => '<!DOCTYPE html>
<html lang="ru">
    <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="robots" content="all" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

<base href="http://sonatel.ru/" />

        <title>404 Ошибка / Сонател</title>
        <meta name="description" content="404 Ошибка" />
        <meta name="keywords" content="Кэйвордс" />
        <meta name="author" content="SONATEL INC." />
        <!-- Bootstrap -->
        <link href="/assets/templates/sonatel/css/bootstrap.min.css" rel="stylesheet" />
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <script src="/assets/templates/sonatel/js/jquery.js"></script>
        <script src="/assets/templates/sonatel/js/bootstrap.min.js"></script>
        <script src="/assets/templates/sonatel/js/lightbox.js"></script>
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href="/assets/templates/sonatel/css/bootstrap-responsive.min.css" rel="stylesheet" />
        <link href="/assets/templates/sonatel/css/main.css" rel="stylesheet" />
    </head>
    <body>
        <!-- Part 1: Wrap all page content here -->
        <div id="page-container">
		            <header style="padding-top: 15px;">
                <div class="container" id="over-the-top">
                    <div class="row">
                        <div class="span4" id="logo-div">
                            <a href="#" title="На главную">
							<img src="/assets/templates/sonatel/img/sonatel_logo.png" alt="СОНАТЕЛ" />
							</a>
                        </div>
                        <!-- <div class="span4" id="main-search-div">
                            <div class="input-append">
                                <input class="span3" id="appendedInputButtons" type="text">
                                <button class="btn" type="button">Поиск</button>
                            </div>
                        </div> -->
                        <div class="span3 pull-right" id="telephone-div">
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                        </div>
                        <!--<div class="span3 pull-right" id="cart-div">
						[[!Shopkeeper@sonatel_shop_small?propertySetName=`sonatel_shop_small`]]

                        </div> -->
                    </div>
                </div>

                <div class="container" id="main-menu">
                    <div class="row">
                        <div class="span12">
                            <div class="navbar navbar-static-top">
                                <div class="navbar-inner">
									<ul class="nav"><li class="first"><a href="http://sonatel.ru/" title="Главная страница" >Главная страница</a></li>
<li><a href="o-nas.html" title="О нас" >О нас</a></li>
<li><a href="catalog/" title="Каталог" >Каталог</a></li>
<li class="last"><a href="kontaktyi.html" title="Контакты" >Контакты</a></li>
</ul>
                                    <a href="#login-form-modal" data-toggle="modal" data-backdrop="false" title="Войти или зарегистрироваться" class="btn btn-primary pull-right btn-mini">Вход/Регистрация</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
			<div class="container">
			                <div class="row">
                    <div class="span12">
					<ul class="breadcrumb"><li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
</ul>
                    </div>
                </div>
                <div class="row" id="main-text-content">
                    <div class="span12">
                        <div class="inner">
                            <h1>404 Ошибка</h1>
                            <p>404 Ошибка</p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="push"></div>
</div>
		<footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="span12" style="text-align:center;"><span class="copy">&copy; SONATEL, 2013 год</span> <br /><a class="sitemap-link" href=karta-sajta.html title="Карта сайта">Карта сайта</a></div>
                </div>
            </div>
        </footer>
        <div id="login-form-modal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel">Вход на сайт</h3>
            </div>
            <div class="modal-body">
                <form class="bs-docs-example form-horizontal">
                    <div class="control-group">
                        <label class="control-label" for="inputEmail">Email</label>
                        <div class="controls">
                            <input type="text" id="inputEmail" placeholder="Email">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Пароль</label>
                        <div class="controls">
                            <input type="password" id="inputPassword" placeholder="Пароль">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <label class="checkbox">
                                <input type="checkbox"> Запомнить меня
                            </label>
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Войти</button>
                            <button class="btn btn-primary">Зарегистрировться</button>
                        </div>
                    </div>

                </form>
            </div>

        </div>
    </body>
</html>',
    '_isForward' => true,
  ),
  'contentType' => 
  array (
    'id' => 1,
    'name' => 'HTML',
    'description' => 'HTML content',
    'mime_type' => 'text/html',
    'file_extensions' => '.html',
    'headers' => NULL,
    'binary' => 0,
  ),
  'policyCache' => 
  array (
  ),
  'elementCache' => 
  array (
    '[[*pagetitle]]' => '404 Ошибка',
    '[[*description]]' => '404 Ошибка',
    '[[$head_tag]]' => '        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="robots" content="all" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

<base href="http://sonatel.ru/" />

        <title>404 Ошибка / Сонател</title>
        <meta name="description" content="404 Ошибка" />
        <meta name="keywords" content="Кэйвордс" />
        <meta name="author" content="SONATEL INC." />
        <!-- Bootstrap -->
        <link href="/assets/templates/sonatel/css/bootstrap.min.css" rel="stylesheet" />
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <script src="/assets/templates/sonatel/js/jquery.js"></script>
        <script src="/assets/templates/sonatel/js/bootstrap.min.js"></script>
        <script src="/assets/templates/sonatel/js/lightbox.js"></script>
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href="/assets/templates/sonatel/css/bootstrap-responsive.min.css" rel="stylesheet" />
        <link href="/assets/templates/sonatel/css/main.css" rel="stylesheet" />',
    '[[*id:isnot=`1`:then=`<a href="#" title="На главную">`]]' => '<a href="#" title="На главную">',
    '[[*id:isnot=`1`:then=`</a>`]]' => '</a>',
    '[[*id:isnot=`31`:then=`[[!Shopkeeper@sonatel_shop_small?propertySetName=`sonatel_shop_small`]]`]]' => '[[!Shopkeeper@sonatel_shop_small?propertySetName=`sonatel_shop_small`]]',
    '[[Wayfinder? &level=`1` &startId=`0` &outerClass=`nav` &contexts=`web`]]' => '<ul class="nav"><li class="first"><a href="http://sonatel.ru/" title="Главная страница" >Главная страница</a></li>
<li><a href="o-nas.html" title="О нас" >О нас</a></li>
<li><a href="catalog/" title="Каталог" >Каталог</a></li>
<li class="last"><a href="kontaktyi.html" title="Контакты" >Контакты</a></li>
</ul>',
    '[[$?text=`404 Ошибка`]]' => '<li class="B_currentCrumb">404 Ошибка</li>',
    '[[~1]]' => 'http://sonatel.ru/',
    '[[$?description=`Вернуться на главную сраницу`&text=`Главная`]]' => '<a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a>',
    '[[$?text=`<a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a>`]]' => '<li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>',
    '[[$?text=`<li class="B_currentCrumb">404 Ошибка</li>`]]' => '<li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>',
    '[[$?text=`<li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
`]]' => '<ul class="breadcrumb"><li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
</ul>',
    '[[Breadcrumbs? &bcTplCrumbOuter=`<ul class="breadcrumb">[[+text]]</ul>`  &bcTplCrumb=`<li class="B_crumb">[[+text]]</li>` &bcTplCrumbCurrent=`<li class="B_currentCrumb">[[+text]]</li>` &bcTplCrumbFirst=`<li class="B_firstCrumb">[[+text]]</li>` &bcTplCrumbLast=`<li class="B_lastCrumb">[[+text]]</li>` &crumbSeparator=`<span class="divider">/</span>` &homeCrumbTitle=`Главная` &homeCrumbDescription=`Вернуться на главную сраницу`]]' => '<ul class="breadcrumb"><li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
</ul>',
    '[[$breadcrumbs_part]]' => '                <div class="row">
                    <div class="span12">
					<ul class="breadcrumb"><li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
</ul>
                    </div>
                </div>',
    '[[*id:isnot=`1`:then=`                <div class="row">
                    <div class="span12">
					<ul class="breadcrumb"><li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
</ul>
                    </div>
                </div>`]]' => '                <div class="row">
                    <div class="span12">
					<ul class="breadcrumb"><li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
</ul>
                    </div>
                </div>',
    '[[$top_part]]' => '            <header style="padding-top: 15px;">
                <div class="container" id="over-the-top">
                    <div class="row">
                        <div class="span4" id="logo-div">
                            <a href="#" title="На главную">
							<img src="/assets/templates/sonatel/img/sonatel_logo.png" alt="СОНАТЕЛ" />
							</a>
                        </div>
                        <!-- <div class="span4" id="main-search-div">
                            <div class="input-append">
                                <input class="span3" id="appendedInputButtons" type="text">
                                <button class="btn" type="button">Поиск</button>
                            </div>
                        </div> -->
                        <div class="span3 pull-right" id="telephone-div">
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                        </div>
                        <!--<div class="span3 pull-right" id="cart-div">
						[[!Shopkeeper@sonatel_shop_small?propertySetName=`sonatel_shop_small`]]

                        </div> -->
                    </div>
                </div>

                <div class="container" id="main-menu">
                    <div class="row">
                        <div class="span12">
                            <div class="navbar navbar-static-top">
                                <div class="navbar-inner">
									<ul class="nav"><li class="first"><a href="http://sonatel.ru/" title="Главная страница" >Главная страница</a></li>
<li><a href="o-nas.html" title="О нас" >О нас</a></li>
<li><a href="catalog/" title="Каталог" >Каталог</a></li>
<li class="last"><a href="kontaktyi.html" title="Контакты" >Контакты</a></li>
</ul>
                                    <a href="#login-form-modal" data-toggle="modal" data-backdrop="false" title="Войти или зарегистрироваться" class="btn btn-primary pull-right btn-mini">Вход/Регистрация</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
			<div class="container">
			                <div class="row">
                    <div class="span12">
					<ul class="breadcrumb"><li class="B_firstCrumb"><a class="B_homeCrumb" itemprop="url" rel="Вернуться на главную сраницу" href="http://sonatel.ru/"><span itemprop="title">Главная</span></a></li>
 <span class="divider">/</span> <li class="B_lastCrumb"><li class="B_currentCrumb">404 Ошибка</li></li>
</ul>
                    </div>
                </div>',
    '[[*longtitle]]' => '404 Ошибка',
    '[[$footer_part]]' => '</div>
		<footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="span12" style="text-align:center;"><span class="copy">&copy; SONATEL, 2013 год</span> <br /><a class="sitemap-link" href=karta-sajta.html title="Карта сайта">Карта сайта</a></div>
                </div>
            </div>
        </footer>
        <div id="login-form-modal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel">Вход на сайт</h3>
            </div>
            <div class="modal-body">
                <form class="bs-docs-example form-horizontal">
                    <div class="control-group">
                        <label class="control-label" for="inputEmail">Email</label>
                        <div class="controls">
                            <input type="text" id="inputEmail" placeholder="Email">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Пароль</label>
                        <div class="controls">
                            <input type="password" id="inputPassword" placeholder="Пароль">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <label class="checkbox">
                                <input type="checkbox"> Запомнить меня
                            </label>
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Войти</button>
                            <button class="btn btn-primary">Зарегистрировться</button>
                        </div>
                    </div>

                </form>
            </div>

        </div>',
    '[[$@INLINE-51cacab74af5e?plugin=``]]' => '<div class="shop-cart ct-empty" id="shopCart">
	<div id="shopCart" class="cart">
		<span class="title">Корзина</span>
		В корзине пусто
	</div>
</div>
',
  ),
  'sourceCache' => 
  array (
    'modChunk' => 
    array (
      'head_tag' => 
      array (
        'fields' => 
        array (
          'id' => 5,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'head_tag',
          'description' => 'Содержимое тега HEAD',
          'editor_type' => 0,
          'category' => 3,
          'cache_type' => 0,
          'snippet' => '        <meta http-equiv="Content-Type" content="text/html; charset=[[++modx_charset]]" />
        <meta name="robots" content="all" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

<base href="[[++site_url]]" />

        <title>[[*pagetitle]] / [[++site_name]]</title>
        <meta name="description" content="[[*description]]" />
        <meta name="keywords" content="Кэйвордс" />
        <meta name="author" content="SONATEL INC." />
        <!-- Bootstrap -->
        <link href="/assets/templates/sonatel/css/bootstrap.min.css" rel="stylesheet" />
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <script src="/assets/templates/sonatel/js/jquery.js"></script>
        <script src="/assets/templates/sonatel/js/bootstrap.min.js"></script>
        <script src="/assets/templates/sonatel/js/lightbox.js"></script>
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href="/assets/templates/sonatel/css/bootstrap-responsive.min.css" rel="stylesheet" />
        <link href="/assets/templates/sonatel/css/main.css" rel="stylesheet" />',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '        <meta http-equiv="Content-Type" content="text/html; charset=[[++modx_charset]]" />
        <meta name="robots" content="all" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

<base href="[[++site_url]]" />

        <title>[[*pagetitle]] / [[++site_name]]</title>
        <meta name="description" content="[[*description]]" />
        <meta name="keywords" content="Кэйвордс" />
        <meta name="author" content="SONATEL INC." />
        <!-- Bootstrap -->
        <link href="/assets/templates/sonatel/css/bootstrap.min.css" rel="stylesheet" />
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <script src="/assets/templates/sonatel/js/jquery.js"></script>
        <script src="/assets/templates/sonatel/js/bootstrap.min.js"></script>
        <script src="/assets/templates/sonatel/js/lightbox.js"></script>
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href="/assets/templates/sonatel/css/bootstrap-responsive.min.css" rel="stylesheet" />
        <link href="/assets/templates/sonatel/css/main.css" rel="stylesheet" />',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'top_part' => 
      array (
        'fields' => 
        array (
          'id' => 6,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'top_part',
          'description' => 'Верхушка всех шаблонов сайта (верхушка с корзиной и лого + меню)',
          'editor_type' => 0,
          'category' => 3,
          'cache_type' => 0,
          'snippet' => '            <header style="padding-top: 15px;">
                <div class="container" id="over-the-top">
                    <div class="row">
                        <div class="span4" id="logo-div">
                            [[*id:isnot=`1`:then=`<a href="#" title="На главную">`]]
							<img src="/assets/templates/sonatel/img/sonatel_logo.png" alt="СОНАТЕЛ" />
							[[*id:isnot=`1`:then=`</a>`]]
                        </div>
                        <!-- <div class="span4" id="main-search-div">
                            <div class="input-append">
                                <input class="span3" id="appendedInputButtons" type="text">
                                <button class="btn" type="button">Поиск</button>
                            </div>
                        </div> -->
                        <div class="span3 pull-right" id="telephone-div">
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                        </div>
                        <!--<div class="span3 pull-right" id="cart-div">
						[[*id:isnot=`31`:then=`[[!Shopkeeper@sonatel_shop_small?propertySetName=`sonatel_shop_small`]]`]]

                        </div> -->
                    </div>
                </div>

                <div class="container" id="main-menu">
                    <div class="row">
                        <div class="span12">
                            <div class="navbar navbar-static-top">
                                <div class="navbar-inner">
									[[Wayfinder? &level=`1` &startId=`0` &outerClass=`nav` &contexts=`web`]]
                                    <a href="#login-form-modal" data-toggle="modal" data-backdrop="false" title="Войти или зарегистрироваться" class="btn btn-primary pull-right btn-mini">Вход/Регистрация</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
			<div class="container">
			[[*id:isnot=`1`:then=`[[$breadcrumbs_part]]`]]',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '            <header style="padding-top: 15px;">
                <div class="container" id="over-the-top">
                    <div class="row">
                        <div class="span4" id="logo-div">
                            [[*id:isnot=`1`:then=`<a href="#" title="На главную">`]]
							<img src="/assets/templates/sonatel/img/sonatel_logo.png" alt="СОНАТЕЛ" />
							[[*id:isnot=`1`:then=`</a>`]]
                        </div>
                        <!-- <div class="span4" id="main-search-div">
                            <div class="input-append">
                                <input class="span3" id="appendedInputButtons" type="text">
                                <button class="btn" type="button">Поиск</button>
                            </div>
                        </div> -->
                        <div class="span3 pull-right" id="telephone-div">
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                            <div>+7 (499) ХХХ-ХХ-ХХ</div>
                        </div>
                        <!--<div class="span3 pull-right" id="cart-div">
						[[*id:isnot=`31`:then=`[[!Shopkeeper@sonatel_shop_small?propertySetName=`sonatel_shop_small`]]`]]

                        </div> -->
                    </div>
                </div>

                <div class="container" id="main-menu">
                    <div class="row">
                        <div class="span12">
                            <div class="navbar navbar-static-top">
                                <div class="navbar-inner">
									[[Wayfinder? &level=`1` &startId=`0` &outerClass=`nav` &contexts=`web`]]
                                    <a href="#login-form-modal" data-toggle="modal" data-backdrop="false" title="Войти или зарегистрироваться" class="btn btn-primary pull-right btn-mini">Вход/Регистрация</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
			<div class="container">
			[[*id:isnot=`1`:then=`[[$breadcrumbs_part]]`]]',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'breadcrumbs_part' => 
      array (
        'fields' => 
        array (
          'id' => 9,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'breadcrumbs_part',
          'description' => 'Часть с хлебными крошками',
          'editor_type' => 0,
          'category' => 3,
          'cache_type' => 0,
          'snippet' => '                <div class="row">
                    <div class="span12">
					[[Breadcrumbs? &bcTplCrumbOuter=`<ul class="breadcrumb">[[+text]]</ul>`  &bcTplCrumb=`<li class="B_crumb">[[+text]]</li>` &bcTplCrumbCurrent=`<li class="B_currentCrumb">[[+text]]</li>` &bcTplCrumbFirst=`<li class="B_firstCrumb">[[+text]]</li>` &bcTplCrumbLast=`<li class="B_lastCrumb">[[+text]]</li>` &crumbSeparator=`<span class="divider">/</span>` &homeCrumbTitle=`Главная` &homeCrumbDescription=`Вернуться на главную сраницу`]]
                    </div>
                </div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '                <div class="row">
                    <div class="span12">
					[[Breadcrumbs? &bcTplCrumbOuter=`<ul class="breadcrumb">[[+text]]</ul>`  &bcTplCrumb=`<li class="B_crumb">[[+text]]</li>` &bcTplCrumbCurrent=`<li class="B_currentCrumb">[[+text]]</li>` &bcTplCrumbFirst=`<li class="B_firstCrumb">[[+text]]</li>` &bcTplCrumbLast=`<li class="B_lastCrumb">[[+text]]</li>` &crumbSeparator=`<span class="divider">/</span>` &homeCrumbTitle=`Главная` &homeCrumbDescription=`Вернуться на главную сраницу`]]
                    </div>
                </div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'footer_part' => 
      array (
        'fields' => 
        array (
          'id' => 8,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'footer_part',
          'description' => 'Подол всех страниц сайта (подол, меню, копирайт и модальные окна)',
          'editor_type' => 0,
          'category' => 3,
          'cache_type' => 0,
          'snippet' => '</div>
		<footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="span12" style="text-align:center;"><span class="copy">&copy; SONATEL, 2013 год</span> <br /><a class="sitemap-link" href=karta-sajta.html title="Карта сайта">Карта сайта</a></div>
                </div>
            </div>
        </footer>
        <div id="login-form-modal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel">Вход на сайт</h3>
            </div>
            <div class="modal-body">
                <form class="bs-docs-example form-horizontal">
                    <div class="control-group">
                        <label class="control-label" for="inputEmail">Email</label>
                        <div class="controls">
                            <input type="text" id="inputEmail" placeholder="Email">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Пароль</label>
                        <div class="controls">
                            <input type="password" id="inputPassword" placeholder="Пароль">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <label class="checkbox">
                                <input type="checkbox"> Запомнить меня
                            </label>
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Войти</button>
                            <button class="btn btn-primary">Зарегистрировться</button>
                        </div>
                    </div>

                </form>
            </div>

        </div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '</div>
		<footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="span12" style="text-align:center;"><span class="copy">&copy; SONATEL, 2013 год</span> <br /><a class="sitemap-link" href=karta-sajta.html title="Карта сайта">Карта сайта</a></div>
                </div>
            </div>
        </footer>
        <div id="login-form-modal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel">Вход на сайт</h3>
            </div>
            <div class="modal-body">
                <form class="bs-docs-example form-horizontal">
                    <div class="control-group">
                        <label class="control-label" for="inputEmail">Email</label>
                        <div class="controls">
                            <input type="text" id="inputEmail" placeholder="Email">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="inputPassword">Пароль</label>
                        <div class="controls">
                            <input type="password" id="inputPassword" placeholder="Пароль">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <label class="checkbox">
                                <input type="checkbox"> Запомнить меня
                            </label>
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Войти</button>
                            <button class="btn btn-primary">Зарегистрировться</button>
                        </div>
                    </div>

                </form>
            </div>

        </div>',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modSnippet' => 
    array (
      'Wayfinder' => 
      array (
        'fields' => 
        array (
          'id' => 15,
          'source' => 0,
          'property_preprocess' => false,
          'name' => 'Wayfinder',
          'description' => 'Wayfinder for MODx Revolution 2.0.0-beta-5 and later.',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '/**
 * Wayfinder Snippet to build site navigation menus
 *
 * Totally refactored from original DropMenu nav builder to make it easier to
 * create custom navigation by using chunks as output templates. By using
 * templates, many of the paramaters are no longer needed for flexible output
 * including tables, unordered- or ordered-lists (ULs or OLs), definition lists
 * (DLs) or in any other format you desire.
 *
 * @version 2.1.1-beta5
 * @author Garry Nutting (collabpad.com)
 * @author Kyle Jaebker (muddydogpaws.com)
 * @author Ryan Thrash (modx.com)
 * @author Shaun McCormick (modx.com)
 * @author Jason Coward (modx.com)
 *
 * @example [[Wayfinder? &startId=`0`]]
 *
 * @var modX $modx
 * @var array $scriptProperties
 * 
 * @package wayfinder
 */
$wayfinder_base = $modx->getOption(\'wayfinder.core_path\',$scriptProperties,$modx->getOption(\'core_path\').\'components/wayfinder/\');

/* include a custom config file if specified */
if (isset($scriptProperties[\'config\'])) {
    $scriptProperties[\'config\'] = str_replace(\'../\',\'\',$scriptProperties[\'config\']);
    $scriptProperties[\'config\'] = $wayfinder_base.\'configs/\'.$scriptProperties[\'config\'].\'.config.php\';
} else {
    $scriptProperties[\'config\'] = $wayfinder_base.\'configs/default.config.php\';
}
if (file_exists($scriptProperties[\'config\'])) {
    include $scriptProperties[\'config\'];
}

/* include wayfinder class */
include_once $wayfinder_base.\'wayfinder.class.php\';
if (!$modx->loadClass(\'Wayfinder\',$wayfinder_base,true,true)) {
    return \'error: Wayfinder class not found\';
}
$wf = new Wayfinder($modx,$scriptProperties);

/* get user class definitions
 * TODO: eventually move these into config parameters */
$wf->_css = array(
    \'first\' => isset($firstClass) ? $firstClass : \'\',
    \'last\' => isset($lastClass) ? $lastClass : \'last\',
    \'here\' => isset($hereClass) ? $hereClass : \'active\',
    \'parent\' => isset($parentClass) ? $parentClass : \'\',
    \'row\' => isset($rowClass) ? $rowClass : \'\',
    \'outer\' => isset($outerClass) ? $outerClass : \'\',
    \'inner\' => isset($innerClass) ? $innerClass : \'\',
    \'level\' => isset($levelClass) ? $levelClass: \'\',
    \'self\' => isset($selfClass) ? $selfClass : \'\',
    \'weblink\' => isset($webLinkClass) ? $webLinkClass : \'\'
);

/* get user templates
 * TODO: eventually move these into config parameters */
$wf->_templates = array(
    \'outerTpl\' => isset($outerTpl) ? $outerTpl : \'\',
    \'rowTpl\' => isset($rowTpl) ? $rowTpl : \'\',
    \'parentRowTpl\' => isset($parentRowTpl) ? $parentRowTpl : \'\',
    \'parentRowHereTpl\' => isset($parentRowHereTpl) ? $parentRowHereTpl : \'\',
    \'hereTpl\' => isset($hereTpl) ? $hereTpl : \'\',
    \'innerTpl\' => isset($innerTpl) ? $innerTpl : \'\',
    \'innerRowTpl\' => isset($innerRowTpl) ? $innerRowTpl : \'\',
    \'innerHereTpl\' => isset($innerHereTpl) ? $innerHereTpl : \'\',
    \'activeParentRowTpl\' => isset($activeParentRowTpl) ? $activeParentRowTpl : \'\',
    \'categoryFoldersTpl\' => isset($categoryFoldersTpl) ? $categoryFoldersTpl : \'\',
    \'startItemTpl\' => isset($startItemTpl) ? $startItemTpl : \'\'
);

/* process Wayfinder */
$output = $wf->run();
if ($wf->_config[\'debug\']) {
    $output .= $wf->renderDebugOutput();
}

/* output results */
if ($wf->_config[\'ph\']) {
    $modx->setPlaceholder($wf->_config[\'ph\'],$output);
} else {
    return $output;
}',
          'locked' => false,
          'properties' => 
          array (
            'level' => 
            array (
              'name' => 'level',
              'desc' => 'prop_wayfinder.level_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '0',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Depth (number of levels) to build the menu from. 0 goes through all levels.',
              'area' => '',
              'area_trans' => '',
            ),
            'includeDocs' => 
            array (
              'name' => 'includeDocs',
              'desc' => 'prop_wayfinder.includeDocs_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '0',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Acts as a filter and will limit the output to only the documents specified in this parameter. The startId is still required.',
              'area' => '',
              'area_trans' => '',
            ),
            'excludeDocs' => 
            array (
              'name' => 'excludeDocs',
              'desc' => 'prop_wayfinder.excludeDocs_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '0',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Acts as a filter and will remove the documents specified in this parameter from the output. The startId is still required.',
              'area' => '',
              'area_trans' => '',
            ),
            'contexts' => 
            array (
              'name' => 'contexts',
              'desc' => 'prop_wayfinder.contexts_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Specify the contexts for the Resources that will be loaded in this menu. Useful when used with startId at 0 to show all first-level items. Note: This will increase load times a bit, but if you set cacheResults to 1, that will offset the load time.',
              'area' => '',
              'area_trans' => '',
            ),
            'cacheResults' => 
            array (
              'name' => 'cacheResults',
              'desc' => 'prop_wayfinder.cacheResults_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => true,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Cache the generated menu to the MODX Resource cache. Setting this to 1 will speed up the loading of your menus.',
              'area' => '',
              'area_trans' => '',
            ),
            'cacheTime' => 
            array (
              'name' => 'cacheTime',
              'desc' => 'prop_wayfinder.cacheTime_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 3600,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'The number of seconds to store the cached menu, if cacheResults is 1. Set to 0 to store indefinitely until cache is manually cleared.',
              'area' => '',
              'area_trans' => '',
            ),
            'ph' => 
            array (
              'name' => 'ph',
              'desc' => 'prop_wayfinder.ph_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'To display send the output of Wayfinder to a placeholder set the ph parameter equal to the name of the desired placeholder. All output including the debugging (if on) will be sent to the placeholder specified.',
              'area' => '',
              'area_trans' => '',
            ),
            'debug' => 
            array (
              'name' => 'debug',
              'desc' => 'prop_wayfinder.debug_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'With the debug parameter set to 1, Wayfinder will output information on how each Resource was processed.',
              'area' => '',
              'area_trans' => '',
            ),
            'ignoreHidden' => 
            array (
              'name' => 'ignoreHidden',
              'desc' => 'prop_wayfinder.ignoreHidden_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'The ignoreHidden parameter allows Wayfinder to ignore the display in menu flag that can be set for each document. With this parameter set to 1, all Resources will be displayed regardless of the Display in Menu flag.',
              'area' => '',
              'area_trans' => '',
            ),
            'hideSubMenus' => 
            array (
              'name' => 'hideSubMenus',
              'desc' => 'prop_wayfinder.hideSubMenus_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'The hideSubMenus parameter will remove all non-active submenus from the Wayfinder output if set to 1. This parameter only works if multiple levels are being displayed.',
              'area' => '',
              'area_trans' => '',
            ),
            'useWeblinkUrl' => 
            array (
              'name' => 'useWeblinkUrl',
              'desc' => 'prop_wayfinder.useWeblinkUrl_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => true,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => ' If WebLinks are used in the output, Wayfinder will output the link specified in the WebLink instead of the normal MODx link. To use the standard display of WebLinks (like any other Resource) set this to 0.',
              'area' => '',
              'area_trans' => '',
            ),
            'fullLink' => 
            array (
              'name' => 'fullLink',
              'desc' => 'prop_wayfinder.fullLink_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'If set to 1, will display the entire, absolute URL in the link. (It is recommended to use scheme instead.)',
              'area' => '',
              'area_trans' => '',
            ),
            'scheme' => 
            array (
              'name' => 'scheme',
              'desc' => 'prop_wayfinder.scheme_desc',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'text' => 'prop_wayfinder.relative',
                  'value' => '',
                  'name' => 'Relative',
                ),
                1 => 
                array (
                  'text' => 'prop_wayfinder.absolute',
                  'value' => 'abs',
                  'name' => 'Absolute',
                ),
                2 => 
                array (
                  'text' => 'prop_wayfinder.full',
                  'value' => 'full',
                  'name' => 'Full',
                ),
              ),
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Determines how URLs are generated for each link. Set to "abs" to show the absolute URL, "full" to show the full URL, and blank to use the relative URL. Defaults to relative.',
              'area' => '',
              'area_trans' => '',
            ),
            'sortOrder' => 
            array (
              'name' => 'sortOrder',
              'desc' => 'prop_wayfinder.sortOrder_desc',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'text' => 'prop_wayfinder.ascending',
                  'value' => 'ASC',
                  'name' => 'Ascending',
                ),
                1 => 
                array (
                  'text' => 'prop_wayfinder.descending',
                  'value' => 'DESC',
                  'name' => 'Descending',
                ),
              ),
              'value' => 'ASC',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Allows the menu to be sorted in either ascending or descending order.',
              'area' => '',
              'area_trans' => '',
            ),
            'sortBy' => 
            array (
              'name' => 'sortBy',
              'desc' => 'prop_wayfinder.sortBy_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 'menuindex',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Sorts the output by any of the Resource fields on a level by level basis. This means that each submenu will be sorted independently of all other submenus at the same level. Random will sort the output differently every time the page is loaded if the snippet is called uncached.',
              'area' => '',
              'area_trans' => '',
            ),
            'limit' => 
            array (
              'name' => 'limit',
              'desc' => 'prop_wayfinder.limit_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '0',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Causes Wayfinder to only process the number of items specified per level.',
              'area' => '',
              'area_trans' => '',
            ),
            'cssTpl' => 
            array (
              'name' => 'cssTpl',
              'desc' => 'prop_wayfinder.cssTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'This parameter allows for a chunk containing a link to a style sheet or style information to be inserted into the head section of the generated page.',
              'area' => '',
              'area_trans' => '',
            ),
            'jsTpl' => 
            array (
              'name' => 'jsTpl',
              'desc' => 'prop_wayfinder.jsTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'This parameter allows for a chunk containing some Javascript to be inserted into the head section of the generated page.',
              'area' => '',
              'area_trans' => '',
            ),
            'rowIdPrefix' => 
            array (
              'name' => 'rowIdPrefix',
              'desc' => 'prop_wayfinder.rowIdPrefix_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'If set, Wayfinder will replace the id placeholder with a unique id consisting of the specified prefix plus the Resource id.',
              'area' => '',
              'area_trans' => '',
            ),
            'textOfLinks' => 
            array (
              'name' => 'textOfLinks',
              'desc' => 'prop_wayfinder.textOfLinks_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 'menutitle',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'This field will be inserted into the linktext placeholder.',
              'area' => '',
              'area_trans' => '',
            ),
            'titleOfLinks' => 
            array (
              'name' => 'titleOfLinks',
              'desc' => 'prop_wayfinder.titleOfLinks_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 'pagetitle',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'This field will be inserted into the linktitle placeholder.',
              'area' => '',
              'area_trans' => '',
            ),
            'displayStart' => 
            array (
              'name' => 'displayStart',
              'desc' => 'prop_wayfinder.displayStart_desc',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Show the document as referenced by startId in the menu.',
              'area' => '',
              'area_trans' => '',
            ),
            'firstClass' => 
            array (
              'name' => 'firstClass',
              'desc' => 'prop_wayfinder.firstClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 'first',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for the first item at a given menu level.',
              'area' => '',
              'area_trans' => '',
            ),
            'lastClass' => 
            array (
              'name' => 'lastClass',
              'desc' => 'prop_wayfinder.lastClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 'last',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for the last item at a given menu level.',
              'area' => '',
              'area_trans' => '',
            ),
            'hereClass' => 
            array (
              'name' => 'hereClass',
              'desc' => 'prop_wayfinder.hereClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 'active',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for the items showing where you are, all the way up the chain.',
              'area' => '',
              'area_trans' => '',
            ),
            'parentClass' => 
            array (
              'name' => 'parentClass',
              'desc' => 'prop_wayfinder.parentClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for menu items that are a container and have children.',
              'area' => '',
              'area_trans' => '',
            ),
            'rowClass' => 
            array (
              'name' => 'rowClass',
              'desc' => 'prop_wayfinder.rowClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class denoting each output row.',
              'area' => '',
              'area_trans' => '',
            ),
            'outerClass' => 
            array (
              'name' => 'outerClass',
              'desc' => 'prop_wayfinder.outerClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for the outer template.',
              'area' => '',
              'area_trans' => '',
            ),
            'innerClass' => 
            array (
              'name' => 'innerClass',
              'desc' => 'prop_wayfinder.innerClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for the inner template.',
              'area' => '',
              'area_trans' => '',
            ),
            'levelClass' => 
            array (
              'name' => 'levelClass',
              'desc' => 'prop_wayfinder.levelClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class denoting every output row level. The level number will be added to the specified class (level1, level2, level3 etc if you specified "level").',
              'area' => '',
              'area_trans' => '',
            ),
            'selfClass' => 
            array (
              'name' => 'selfClass',
              'desc' => 'prop_wayfinder.selfClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for the current item.',
              'area' => '',
              'area_trans' => '',
            ),
            'webLinkClass' => 
            array (
              'name' => 'webLinkClass',
              'desc' => 'prop_wayfinder.webLinkClass_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'CSS class for weblink items.',
              'area' => '',
              'area_trans' => '',
            ),
            'outerTpl' => 
            array (
              'name' => 'outerTpl',
              'desc' => 'prop_wayfinder.outerTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for the outer most container; if not included, a string including "<ul>[[+wf.wrapper]]</ul>" is assumed.',
              'area' => '',
              'area_trans' => '',
            ),
            'rowTpl' => 
            array (
              'name' => 'rowTpl',
              'desc' => 'prop_wayfinder.rowTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for the regular row items.',
              'area' => '',
              'area_trans' => '',
            ),
            'parentRowTpl' => 
            array (
              'name' => 'parentRowTpl',
              'desc' => 'prop_wayfinder.parentRowTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for any Resource that is a container and has children. Remember the [wf.wrapper] placeholder to output the children documents.',
              'area' => '',
              'area_trans' => '',
            ),
            'parentRowHereTpl' => 
            array (
              'name' => 'parentRowHereTpl',
              'desc' => 'prop_wayfinder.parentRowHereTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for the current Resource if it is a container and has children. Remember the [wf.wrapper] placeholder to output the children documents.',
              'area' => '',
              'area_trans' => '',
            ),
            'hereTpl' => 
            array (
              'name' => 'hereTpl',
              'desc' => 'prop_wayfinder.hereTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for the current Resource.',
              'area' => '',
              'area_trans' => '',
            ),
            'innerTpl' => 
            array (
              'name' => 'innerTpl',
              'desc' => 'prop_wayfinder.innerTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for each submenu. If no innerTpl is specified the outerTpl is used in its place.',
              'area' => '',
              'area_trans' => '',
            ),
            'innerRowTpl' => 
            array (
              'name' => 'innerRowTpl',
              'desc' => 'prop_wayfinder.innerRowTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for the row items in a subfolder.',
              'area' => '',
              'area_trans' => '',
            ),
            'innerHereTpl' => 
            array (
              'name' => 'innerHereTpl',
              'desc' => 'prop_wayfinder.innerHereTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for the current Resource if it is in a subfolder.',
              'area' => '',
              'area_trans' => '',
            ),
            'activeParentRowTpl' => 
            array (
              'name' => 'activeParentRowTpl',
              'desc' => 'prop_wayfinder.activeParentRowTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for items that are containers, have children and are currently active in the tree.',
              'area' => '',
              'area_trans' => '',
            ),
            'categoryFoldersTpl' => 
            array (
              'name' => 'categoryFoldersTpl',
              'desc' => 'prop_wayfinder.categoryFoldersTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for category folders. Category folders are determined by setting the template to blank or by setting the link attributes field to rel="category".',
              'area' => '',
              'area_trans' => '',
            ),
            'startItemTpl' => 
            array (
              'name' => 'startItemTpl',
              'desc' => 'prop_wayfinder.startItemTpl_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Name of the chunk containing the template for the start item, if enabled via the &displayStart parameter. Note: the default template shows the start item but does not link it. If you do not need a link, a class can be applied to the default template using the parameter &firstClass=`className`.',
              'area' => '',
              'area_trans' => '',
            ),
            'permissions' => 
            array (
              'name' => 'permissions',
              'desc' => 'prop_wayfinder.permissions_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => 'list',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Will check for a permission on the Resource. Defaults to "list" - set to blank to skip normal permissions checks.',
              'area' => '',
              'area_trans' => '',
            ),
            'hereId' => 
            array (
              'name' => 'hereId',
              'desc' => 'prop_wayfinder.hereId_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Optional. If set, will change the "here" Resource to this ID. Defaults to the currently active Resource.',
              'area' => '',
              'area_trans' => '',
            ),
            'where' => 
            array (
              'name' => 'where',
              'desc' => 'prop_wayfinder.where_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Optional. A JSON object for where conditions for all items selected in the menu.',
              'area' => '',
              'area_trans' => '',
            ),
            'templates' => 
            array (
              'name' => 'templates',
              'desc' => 'prop_wayfinder.templates_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Optional. A comma-separated list of Template IDs to restrict selected Resources to.',
              'area' => '',
              'area_trans' => '',
            ),
            'previewUnpublished' => 
            array (
              'name' => 'previewUnpublished',
              'desc' => 'prop_wayfinder.previewunpublished_desc',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'wayfinder:properties',
              'desc_trans' => 'Optional. If set to Yes, if you are logged into the mgr and have the view_unpublished permission, it will allow previewing of unpublished resources in your menus in the front-end.',
              'area' => '',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => '',
          'content' => '/**
 * Wayfinder Snippet to build site navigation menus
 *
 * Totally refactored from original DropMenu nav builder to make it easier to
 * create custom navigation by using chunks as output templates. By using
 * templates, many of the paramaters are no longer needed for flexible output
 * including tables, unordered- or ordered-lists (ULs or OLs), definition lists
 * (DLs) or in any other format you desire.
 *
 * @version 2.1.1-beta5
 * @author Garry Nutting (collabpad.com)
 * @author Kyle Jaebker (muddydogpaws.com)
 * @author Ryan Thrash (modx.com)
 * @author Shaun McCormick (modx.com)
 * @author Jason Coward (modx.com)
 *
 * @example [[Wayfinder? &startId=`0`]]
 *
 * @var modX $modx
 * @var array $scriptProperties
 * 
 * @package wayfinder
 */
$wayfinder_base = $modx->getOption(\'wayfinder.core_path\',$scriptProperties,$modx->getOption(\'core_path\').\'components/wayfinder/\');

/* include a custom config file if specified */
if (isset($scriptProperties[\'config\'])) {
    $scriptProperties[\'config\'] = str_replace(\'../\',\'\',$scriptProperties[\'config\']);
    $scriptProperties[\'config\'] = $wayfinder_base.\'configs/\'.$scriptProperties[\'config\'].\'.config.php\';
} else {
    $scriptProperties[\'config\'] = $wayfinder_base.\'configs/default.config.php\';
}
if (file_exists($scriptProperties[\'config\'])) {
    include $scriptProperties[\'config\'];
}

/* include wayfinder class */
include_once $wayfinder_base.\'wayfinder.class.php\';
if (!$modx->loadClass(\'Wayfinder\',$wayfinder_base,true,true)) {
    return \'error: Wayfinder class not found\';
}
$wf = new Wayfinder($modx,$scriptProperties);

/* get user class definitions
 * TODO: eventually move these into config parameters */
$wf->_css = array(
    \'first\' => isset($firstClass) ? $firstClass : \'\',
    \'last\' => isset($lastClass) ? $lastClass : \'last\',
    \'here\' => isset($hereClass) ? $hereClass : \'active\',
    \'parent\' => isset($parentClass) ? $parentClass : \'\',
    \'row\' => isset($rowClass) ? $rowClass : \'\',
    \'outer\' => isset($outerClass) ? $outerClass : \'\',
    \'inner\' => isset($innerClass) ? $innerClass : \'\',
    \'level\' => isset($levelClass) ? $levelClass: \'\',
    \'self\' => isset($selfClass) ? $selfClass : \'\',
    \'weblink\' => isset($webLinkClass) ? $webLinkClass : \'\'
);

/* get user templates
 * TODO: eventually move these into config parameters */
$wf->_templates = array(
    \'outerTpl\' => isset($outerTpl) ? $outerTpl : \'\',
    \'rowTpl\' => isset($rowTpl) ? $rowTpl : \'\',
    \'parentRowTpl\' => isset($parentRowTpl) ? $parentRowTpl : \'\',
    \'parentRowHereTpl\' => isset($parentRowHereTpl) ? $parentRowHereTpl : \'\',
    \'hereTpl\' => isset($hereTpl) ? $hereTpl : \'\',
    \'innerTpl\' => isset($innerTpl) ? $innerTpl : \'\',
    \'innerRowTpl\' => isset($innerRowTpl) ? $innerRowTpl : \'\',
    \'innerHereTpl\' => isset($innerHereTpl) ? $innerHereTpl : \'\',
    \'activeParentRowTpl\' => isset($activeParentRowTpl) ? $activeParentRowTpl : \'\',
    \'categoryFoldersTpl\' => isset($categoryFoldersTpl) ? $categoryFoldersTpl : \'\',
    \'startItemTpl\' => isset($startItemTpl) ? $startItemTpl : \'\'
);

/* process Wayfinder */
$output = $wf->run();
if ($wf->_config[\'debug\']) {
    $output .= $wf->renderDebugOutput();
}

/* output results */
if ($wf->_config[\'ph\']) {
    $modx->setPlaceholder($wf->_config[\'ph\'],$output);
} else {
    return $output;
}',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
        ),
      ),
      'Breadcrumbs' => 
      array (
        'fields' => 
        array (
          'id' => 16,
          'source' => 0,
          'property_preprocess' => false,
          'name' => 'Breadcrumbs',
          'description' => '',
          'editor_type' => 0,
          'category' => 6,
          'cache_type' => 0,
          'snippet' => '/**
 * BreadCrumbs
 *
 * Copyright 2009-2011 by Shaun McCormick <shaun+bc@modx.com>
 *
 * BreadCrumbs is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) any
 * later version.
 *
 * BreadCrumbs is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * BreadCrumbs; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
 * Suite 330, Boston, MA 02111-1307 USA
 *
 * @package breadcrumbs
 */
/**
 * @name BreadCrumbs
 * @version 0.9f
 * @created 2006-06-12
 * @since 2009-05-11
 * @author Jared <jaredc@honeydewdesign.com>
 * @editor Bill Wilson
 * @editor wendy@djamoer.net
 * @editor grad
 * @editor Shaun McCormick <shaun@collabpad.com>
 * @editor Shawn Wilkerson <shawn@shawnwilkerson.com>
 * @editor Wieger Sloot, Sterc.nl <wieger@sterc.nl>
 * @tester Bob Ray
 * @package breadcrumbs
 *
 * This snippet was designed to show the path through the various levels of site
 * structure back to the root. It is NOT necessarily the path the user took to
 * arrive at a given page.
 *
 * @see breadcrumbs.class.php for config settings
 *
 * Included classes
 * .B_crumbBox Span that surrounds all crumb output
 * .B_hideCrumb Span surrounding the "..." if there are more crumbs than will be shown
 * .B_currentCrumb Span or A tag surrounding the current crumb
 * .B_firstCrumb Span that always surrounds the first crumb, whether it is "home" or not
 * .B_lastCrumb Span surrounding last crumb, whether it is the current page or not .
 * .B_crumb Class given to each A tag surrounding the intermediate crumbs (not home, or
 * hide)
 * .B_homeCrumb Class given to the home crumb
 */
require_once $modx->getOption(\'breadcrumbs.core_path\',null,$modx->getOption(\'core_path\').\'components/breadcrumbs/\').\'model/breadcrumbs/breadcrumbs.class.php\';
$bc = new BreadCrumbs($modx,$scriptProperties);
return $bc->run();',
          'locked' => false,
          'properties' => NULL,
          'moduleguid' => '',
          'static' => false,
          'static_file' => '',
          'content' => '/**
 * BreadCrumbs
 *
 * Copyright 2009-2011 by Shaun McCormick <shaun+bc@modx.com>
 *
 * BreadCrumbs is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) any
 * later version.
 *
 * BreadCrumbs is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * BreadCrumbs; if not, write to the Free Software Foundation, Inc., 59 Temple Place,
 * Suite 330, Boston, MA 02111-1307 USA
 *
 * @package breadcrumbs
 */
/**
 * @name BreadCrumbs
 * @version 0.9f
 * @created 2006-06-12
 * @since 2009-05-11
 * @author Jared <jaredc@honeydewdesign.com>
 * @editor Bill Wilson
 * @editor wendy@djamoer.net
 * @editor grad
 * @editor Shaun McCormick <shaun@collabpad.com>
 * @editor Shawn Wilkerson <shawn@shawnwilkerson.com>
 * @editor Wieger Sloot, Sterc.nl <wieger@sterc.nl>
 * @tester Bob Ray
 * @package breadcrumbs
 *
 * This snippet was designed to show the path through the various levels of site
 * structure back to the root. It is NOT necessarily the path the user took to
 * arrive at a given page.
 *
 * @see breadcrumbs.class.php for config settings
 *
 * Included classes
 * .B_crumbBox Span that surrounds all crumb output
 * .B_hideCrumb Span surrounding the "..." if there are more crumbs than will be shown
 * .B_currentCrumb Span or A tag surrounding the current crumb
 * .B_firstCrumb Span that always surrounds the first crumb, whether it is "home" or not
 * .B_lastCrumb Span surrounding last crumb, whether it is the current page or not .
 * .B_crumb Class given to each A tag surrounding the intermediate crumbs (not home, or
 * hide)
 * .B_homeCrumb Class given to the home crumb
 */
require_once $modx->getOption(\'breadcrumbs.core_path\',null,$modx->getOption(\'core_path\').\'components/breadcrumbs/\').\'model/breadcrumbs/breadcrumbs.class.php\';
$bc = new BreadCrumbs($modx,$scriptProperties);
return $bc->run();',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
        ),
      ),
      'Shopkeeper' => 
      array (
        'fields' => 
        array (
          'id' => 1,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'Shopkeeper',
          'description' => 'Shopping cart',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '/**
 * Shopkeeper
 * 
 * Shopping cart for MODx Revolution
 * 
 * @category 	   snippet
 * @version 	   2.2.9
 * @license 	   http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	   @properties
 * @internal	   @modx_category Shop
 */

//ini_set(\'display_errors\',1);
//error_reporting(E_ALL);

if(isset($hideOn) && preg_match(\'/(^|\\s|,)\'.$modx->resource->get(\'id\').\'(,|$)/\',$hideOn)) return \'\';

$modx->placeholders[\'SHK_callCount\'] = isset($modx->placeholders[\'SHK_callCount\']) ? $modx->placeholders[\'SHK_callCount\']+1 : 1;
$SHK_callCount = $modx->placeholders[\'SHK_callCount\'];
if($SHK_callCount>1) return \'\';

$manager_language = $modx->config[\'manager_language\'];
$charset = $modx->config[\'modx_charset\'];
$isfolder = $modx->resource->get(\'isfolder\');
$propertySetName = $modx->getOption(\'propertySetName\',$scriptProperties,\'default\');
$debug = $modx->getOption(\'debug\',$scriptProperties,false);

if(!defined(\'SHOPKEEPER_PATH\')) define(\'SHOPKEEPER_PATH\', MODX_CORE_PATH."components/shopkeeper/");
if(!defined(\'SHOPKEEPER_URL\')) define(\'SHOPKEEPER_URL\', MODX_BASE_URL."core/components/shopkeeper/");
if(!defined(\'SHOPKEEPER_ASSETS_PATH\')) define(\'SHOPKEEPER_ASSETS_PATH\', MODX_BASE_PATH."assets/components/shopkeeper/");
if(!defined(\'SHOPKEEPER_ASSETS_URL\')) define(\'SHOPKEEPER_ASSETS_URL\', MODX_BASE_URL."assets/components/shopkeeper/");

$modx->addPackage(\'shopkeeper\',SHOPKEEPER_PATH.\'model/\');

//require_once SHOPKEEPER_PATH."include.parsetpl.php";
require_once SHOPKEEPER_PATH."model/shopkeeper.class.php";
$shopCart = new Shopkeeper($modx, $scriptProperties);

$output = \'\';

//добавление товара в корзину
if(isset($_POST[\'shk-id\'])){
    
    $purchaseArray = $_POST;
    $shopCart -> savePurchaseData($purchaseArray);
    $modx->sendRedirect((!empty($_SERVER[\'HTTP_REFERER\']) ? $_SERVER[\'HTTP_REFERER\'] : $modx->makeURL($modx->resource->get(\'id\'),\'\',\'\',\'abs\')),0);
    exit;

}elseif(isset($_GET[\'shk_action\'])){
  
    $action = addslashes($_GET[\'shk_action\']);
     
    switch($action){
        case "empty"://очистка корзины
            $shopCart->emptySavedData();
        break;
        case "del"://удаление товара из корзины
            $item_index = isset($_GET[\'n\']) && is_numeric($_GET[\'n\']) ? $_GET[\'n\'] : \'\';
            $shopCart->delArrayItem($item_index);
        break;
    }
    
    $modx->sendRedirect((!empty($_SERVER[\'HTTP_REFERER\']) ? $_SERVER[\'HTTP_REFERER\'] : $modx->makeURL($modx->resource->get(\'id\'),\'\',\'\',\'abs\')),0);
    exit;

//пересчет количества товаров в корзине
}elseif(isset($_POST[\'shk_recount\'])){
  
    if(!empty($_POST[\'count\'])){
        $shopCart->recountAll($_POST[\'count\']);
        $modx->sendRedirect((!empty($_SERVER[\'HTTP_REFERER\']) ? $_SERVER[\'HTTP_REFERER\'] : $modx->makeURL($modx->resource->get(\'id\'),\'\',\'\',\'abs\')),0);
        exit;
    }

}

//добавление стилей и скриптов в <head>, если нужно
$headHtml = "";

if(!empty($scriptProperties[\'style\'])){
    $modx->regClientCSS(SHOPKEEPER_ASSETS_URL."css/web/".$modx->getOption(\'style\',$scriptProperties,\'default\')."/style.css");
}

if(!$modx->getOption(\'noJavaScript\',$scriptProperties,false)){
    
    if(!$modx->getOption(\'noJQuery\',$scriptProperties,false)){
        $modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/jquery-1.8.2.min.js");
    }
    
    //$modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/jquery.livequery.js");
    $modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/lang/{$lang}.js?v=".$shopCart->version);
    $modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/shopkeeper.js?v=".$shopCart->version);
    
    $headHtml .= \'
    <script type="text/javascript">\';
      
    if($modx->getOption(\'noConflict\',$scriptProperties,false)){$headHtml .= "
        jQuery.noConflict();";
    }
    
    list($price_total,$items_total,$items_unique_total) = $shopCart->getTotal();
    
    $headHtml .= "
    var site_base_url = \'".$modx->config[\'base_url\']."\';
    var shkOpt = jQuery.extend(shkOptDefault,{";
    $headHtml .= "prodCont:\'".$scriptProperties[\'prodCont\']."\'";
    if($modx->getOption(\'lang\',$scriptProperties,null)!=\'ru\') $headHtml .= ", lang:\'".$scriptProperties[\'lang\']."\'";
    if($modx->getOption(\'currency\',$scriptProperties,null)!=\'руб.\') $headHtml .= ", currency: \'".$scriptProperties[\'currency\']."\'";
    $headHtml .= ", orderFormPage:\'".$modx->getOption(\'orderFormPage\',$scriptProperties,1)."\'";
    $headHtml .= ", orderFormPageUrl:\'".$modx->makeUrl($modx->getOption(\'orderFormPage\',$scriptProperties,0),\'\',\'\',\'abs\')."\'";
    if($modx->getOption(\'counterField\',$scriptProperties,null)==true) $headHtml .= ", counterField:true";
    if($modx->getOption(\'counterFieldCart\',$scriptProperties,null)==true) $headHtml .= ", counterFieldCart:true";
    if($scriptProperties[\'changePrice\']) $headHtml .= ", changePrice:".($scriptProperties[\'changePrice\']==\'replace\' ? "\'replace\'" : \'true\');
    if($modx->getOption(\'noCounter\',$scriptProperties,null)==true) $headHtml .= ", noCounter:true";
    if($modx->getOption(\'flyToCart\',$scriptProperties,null)!=\'helper\') $headHtml .= ", flyToCart:\'".$scriptProperties[\'flyToCart\']."\'";
    if($modx->getOption(\'style\',$scriptProperties,null)!=\'default\') $headHtml .= ", style:\'".$scriptProperties[\'style\']."\'";
    if($modx->getOption(\'noLoader\',$scriptProperties,null)==true) $headHtml .= ", noLoader:true";
    if($modx->getOption(\'allowFloatCount\',$scriptProperties,null)==true) $headHtml .= ", allowFloatCount:true";
    if($modx->getOption(\'animCart\',$scriptProperties,null)==false) $headHtml .= ", animCart:false";
    if($modx->getOption(\'goToOrderFormPage\',$scriptProperties,null)!=false) $headHtml .= ", goToOrderFormPage:true";
    if($debug) $headHtml .= ", debug:true";
    $headHtml .= ", psn:\'".$shopCart->encrypt($propertySetName)."\'";
    
    if(!empty($scriptProperties[\'cartHelperTpl\'])){
        $helperChunk = $shopCart->getChunk($scriptProperties[\'cartHelperTpl\']);
        $helperChunk_arr = preg_split("/[\\r\\n]+/", trim($helperChunk->get(\'snippet\')));
        $helperStr = \'\';
        for($i=0;$i<count($helperChunk_arr);$i++){
            $helperStr .= ($i>0 ? \'+\' : \'\')."\'".str_replace("\'","\\\'",trim($helperChunk_arr[$i]))."\'\\n";
        }
        $headHtml .= "\\n, shkHelper:{$helperStr}";
    }
  
    $headHtml .= "});
    SHK.data = {price_total:{$price_total}, items_total:{$items_total}, items_unique_total:{$items_unique_total}, ids:[".$shopCart->getProdIds(\'string\')."]};
    jQuery(document).bind(\'ready\',function(){
        jQuery(shkOpt.prodCont).shopkeeper();
    });";
    
    $headHtml .= "
    </script>";
    
    $modx->regClientStartupHTMLBlock($headHtml);
    
}

//вывод корзины
$output .= $shopCart->getCartContent();

//Вывод отладочной информации
if($debug){
    $curSavedP = !empty($_SESSION[\'shk_purchases\']) ? $_SESSION[\'shk_purchases\'] : array();
    $curSavedA = !empty($_SESSION[\'shk_addit_params\']) ? $_SESSION[\'shk_addit_params\'] : array();
    $output .= \'<pre>\'.print_r($curSavedP,true).print_r($curSavedA,true).\'</pre>\';
}

return $output;',
          'locked' => false,
          'properties' => 
          array (
            'lang' => 
            array (
              'name' => 'lang',
              'desc' => 'prop_shk.lang',
              'type' => 'textfield',
              'options' => '',
              'value' => 'ru',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Язык',
              'area_trans' => '',
            ),
            'prodCont' => 
            array (
              'name' => 'prodCont',
              'desc' => 'prop_shk.prodcont',
              'type' => 'textfield',
              'options' => '',
              'value' => 'div.shk-item',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'CSS-селектор элемента, внутри которого находится информация о товаре',
              'area_trans' => '',
            ),
            'tplPath' => 
            array (
              'name' => 'tplPath',
              'desc' => 'prop_shk.tplpath',
              'type' => 'textfield',
              'options' => '',
              'value' => 'core/components/shopkeeper/elements/chunks/ru/',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Путь до папки с чанками сниппета',
              'area_trans' => '',
            ),
            'cartTpl' => 
            array (
              'name' => 'cartTpl',
              'desc' => 'prop_shk.carttpl',
              'type' => 'textfield',
              'options' => '',
              'value' => '@FILE shopCart.tpl',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Шаблон корзины',
              'area_trans' => '',
            ),
            'cartRowTpl' => 
            array (
              'name' => 'cartRowTpl',
              'desc' => 'prop_shk.cartrowtpl',
              'type' => 'textfield',
              'options' => '',
              'value' => '@FILE shopCartRow.tpl',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Шаблон строки корзины',
              'area_trans' => '',
            ),
            'additDataTpl' => 
            array (
              'name' => 'additDataTpl',
              'desc' => 'prop_shk.additdatatpl',
              'type' => 'textfield',
              'options' => '',
              'value' => '@FILE additData.tpl',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Шаблон для доп. параметров в корзине',
              'area_trans' => '',
            ),
            'orderDataTpl' => 
            array (
              'name' => 'orderDataTpl',
              'desc' => 'prop_shk.orderdatatpl',
              'type' => 'textfield',
              'options' => '',
              'value' => '@FILE orderData.tpl',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Шаблон для содержимого заказа',
              'area_trans' => '',
            ),
            'cartHelperTpl' => 
            array (
              'name' => 'cartHelperTpl',
              'desc' => 'prop_shk.carthelpetpl',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Шаблон для всплывающего блока (хелпера)',
              'area_trans' => '',
            ),
            'flyToCart' => 
            array (
              'name' => 'flyToCart',
              'desc' => 'prop_shk.flytocart',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'text' => 'helper',
                  'value' => 'helper',
                  'name' => 'helper',
                ),
                1 => 
                array (
                  'text' => 'image',
                  'value' => 'image',
                  'name' => 'image',
                ),
                2 => 
                array (
                  'text' => 'scrollimage',
                  'value' => 'scrollimage',
                  'name' => 'scrollimage',
                ),
                3 => 
                array (
                  'text' => 'nofly',
                  'value' => 'nofly',
                  'name' => 'nofly',
                ),
              ),
              'value' => 'helper',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Эффект добавления товара в корзину',
              'area_trans' => '',
            ),
            'priceTV' => 
            array (
              'name' => 'priceTV',
              'desc' => 'prop_shk.pricetv',
              'type' => 'textfield',
              'options' => '',
              'value' => 'price',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Имя TV параметра цены',
              'area_trans' => '',
            ),
            'style' => 
            array (
              'name' => 'style',
              'desc' => 'prop_shk.style',
              'type' => 'textfield',
              'options' => '',
              'value' => 'default',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Стиль корзины',
              'area_trans' => '',
            ),
            'currency' => 
            array (
              'name' => 'currency',
              'desc' => 'prop_shk.currency',
              'type' => 'textfield',
              'options' => '',
              'value' => 'руб.',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Валюта по умолчанию',
              'area_trans' => '',
            ),
            'noCounter' => 
            array (
              'name' => 'noCounter',
              'desc' => 'prop_shk.nocounter',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Не показывать стрелки изменения кол-ва товара',
              'area_trans' => '',
            ),
            'noLoader' => 
            array (
              'name' => 'noLoader',
              'desc' => 'prop_shk.noloader',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Не показывать прелоадер',
              'area_trans' => '',
            ),
            'orderFormPage' => 
            array (
              'name' => 'orderFormPage',
              'desc' => 'prop_shk.orderformpage',
              'type' => 'textfield',
              'options' => '',
              'value' => '1',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'ID страницы с формой оформления заказа',
              'area_trans' => '',
            ),
            'goToOrderFormPage' => 
            array (
              'name' => 'goToOrderFormPage',
              'desc' => 'prop_shk.gotoorderformpage',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Переходить на страницу оформления заказа сразу после добавлении товара в корзину',
              'area_trans' => '',
            ),
            'counterField' => 
            array (
              'name' => 'counterField',
              'desc' => 'prop_shk.counterfield',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Добавить ко всем полям кол-ва товара стрелки больше/меньше',
              'area_trans' => '',
            ),
            'counterFieldCart' => 
            array (
              'name' => 'counterFieldCart',
              'desc' => 'prop_shk.counterFieldCart',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Добавить ко всем полям кол-ва товара в корзине стрелки больше/меньше',
              'area_trans' => '',
            ),
            'excepDigitGroup' => 
            array (
              'name' => 'excepDigitGroup',
              'desc' => 'prop_shk.excepdigitgroup',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => true,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Разделять числа цен в корзине на разряды',
              'area_trans' => '',
            ),
            'changePrice' => 
            array (
              'name' => 'changePrice',
              'desc' => 'prop_shk.changeprice',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'text' => 'yes',
                  'value' => '1',
                  'name' => 'yes',
                ),
                1 => 
                array (
                  'text' => 'no',
                  'value' => '0',
                  'name' => 'no',
                ),
                2 => 
                array (
                  'text' => 'replace',
                  'value' => 'replace',
                  'name' => 'replace',
                ),
              ),
              'value' => '1',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'При изменении параметров с ценой - изменяется цена товара, а индекс с плюсом не появляется',
              'area_trans' => '',
            ),
            'animCart' => 
            array (
              'name' => 'animCart',
              'desc' => 'prop_shk.animcart',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => true,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Анимация изменения высоты корзины',
              'area_trans' => '',
            ),
            'allowFloatCount' => 
            array (
              'name' => 'allowFloatCount',
              'desc' => 'prop_shk.allowfloatcount',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Разрешить покупать дробное число товара',
              'area_trans' => '',
            ),
            'noJavaScript' => 
            array (
              'name' => 'noJavaScript',
              'desc' => 'prop_shk.nojavascript',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Работать без JavaScript',
              'area_trans' => '',
            ),
            'noJQuery' => 
            array (
              'name' => 'noJQuery',
              'desc' => 'prop_shk.nojquery',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Не подгружать jquery.js',
              'area_trans' => '',
            ),
            'noConflict' => 
            array (
              'name' => 'noConflict',
              'desc' => 'prop_shk.noconflict',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Включить режим noConflict для jQuery. Используется, если на сайте уже используется другая JS-библиотека (не jQuery)',
              'area_trans' => '',
            ),
            'hideOn' => 
            array (
              'name' => 'hideOn',
              'desc' => 'prop_shk.hideon',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Не выводить корзину на страницах (id через запятую)',
              'area_trans' => '',
            ),
            'TVsaveList' => 
            array (
              'name' => 'TVsaveList',
              'desc' => 'prop_shk.TVsaveList',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Список имён TV-параметров, которые нужно сохранить в БД при отправке заказа. Если пусто, сохраняются все TV.',
              'area_trans' => '',
            ),
            'fromParentList' => 
            array (
              'name' => 'fromParentList',
              'desc' => 'prop_shk.fromParentList',
              'type' => 'textfield',
              'options' => '',
              'value' => '',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Список полей через запятую, которые нужно добавить товарам от родителей',
              'area_trans' => '',
            ),
            'fromParentHeight' => 
            array (
              'name' => 'fromParentHeight',
              'desc' => 'prop_shk.fromParentHeight',
              'type' => 'textfield',
              'options' => '',
              'value' => '1',
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Сколько уровней родителей учитывать при использовании параметра fromParentList',
              'area_trans' => '',
            ),
            'debug' => 
            array (
              'name' => 'debug',
              'desc' => 'prop_shk.debug',
              'type' => 'combo-boolean',
              'options' => '',
              'value' => false,
              'lexicon' => 'shopkeeper:properties',
              'area' => '',
              'desc_trans' => 'Включить режим отладки',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => true,
          'static_file' => 'core/components/shopkeeper/shopkeeper.inc.php',
          'content' => '/**
 * Shopkeeper
 * 
 * Shopping cart for MODx Revolution
 * 
 * @category 	   snippet
 * @version 	   2.2.9
 * @license 	   http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	   @properties
 * @internal	   @modx_category Shop
 */

//ini_set(\'display_errors\',1);
//error_reporting(E_ALL);

if(isset($hideOn) && preg_match(\'/(^|\\s|,)\'.$modx->resource->get(\'id\').\'(,|$)/\',$hideOn)) return \'\';

$modx->placeholders[\'SHK_callCount\'] = isset($modx->placeholders[\'SHK_callCount\']) ? $modx->placeholders[\'SHK_callCount\']+1 : 1;
$SHK_callCount = $modx->placeholders[\'SHK_callCount\'];
if($SHK_callCount>1) return \'\';

$manager_language = $modx->config[\'manager_language\'];
$charset = $modx->config[\'modx_charset\'];
$isfolder = $modx->resource->get(\'isfolder\');
$propertySetName = $modx->getOption(\'propertySetName\',$scriptProperties,\'default\');
$debug = $modx->getOption(\'debug\',$scriptProperties,false);

if(!defined(\'SHOPKEEPER_PATH\')) define(\'SHOPKEEPER_PATH\', MODX_CORE_PATH."components/shopkeeper/");
if(!defined(\'SHOPKEEPER_URL\')) define(\'SHOPKEEPER_URL\', MODX_BASE_URL."core/components/shopkeeper/");
if(!defined(\'SHOPKEEPER_ASSETS_PATH\')) define(\'SHOPKEEPER_ASSETS_PATH\', MODX_BASE_PATH."assets/components/shopkeeper/");
if(!defined(\'SHOPKEEPER_ASSETS_URL\')) define(\'SHOPKEEPER_ASSETS_URL\', MODX_BASE_URL."assets/components/shopkeeper/");

$modx->addPackage(\'shopkeeper\',SHOPKEEPER_PATH.\'model/\');

//require_once SHOPKEEPER_PATH."include.parsetpl.php";
require_once SHOPKEEPER_PATH."model/shopkeeper.class.php";
$shopCart = new Shopkeeper($modx, $scriptProperties);

$output = \'\';

//добавление товара в корзину
if(isset($_POST[\'shk-id\'])){
    
    $purchaseArray = $_POST;
    $shopCart -> savePurchaseData($purchaseArray);
    $modx->sendRedirect((!empty($_SERVER[\'HTTP_REFERER\']) ? $_SERVER[\'HTTP_REFERER\'] : $modx->makeURL($modx->resource->get(\'id\'),\'\',\'\',\'abs\')),0);
    exit;

}elseif(isset($_GET[\'shk_action\'])){
  
    $action = addslashes($_GET[\'shk_action\']);
     
    switch($action){
        case "empty"://очистка корзины
            $shopCart->emptySavedData();
        break;
        case "del"://удаление товара из корзины
            $item_index = isset($_GET[\'n\']) && is_numeric($_GET[\'n\']) ? $_GET[\'n\'] : \'\';
            $shopCart->delArrayItem($item_index);
        break;
    }
    
    $modx->sendRedirect((!empty($_SERVER[\'HTTP_REFERER\']) ? $_SERVER[\'HTTP_REFERER\'] : $modx->makeURL($modx->resource->get(\'id\'),\'\',\'\',\'abs\')),0);
    exit;

//пересчет количества товаров в корзине
}elseif(isset($_POST[\'shk_recount\'])){
  
    if(!empty($_POST[\'count\'])){
        $shopCart->recountAll($_POST[\'count\']);
        $modx->sendRedirect((!empty($_SERVER[\'HTTP_REFERER\']) ? $_SERVER[\'HTTP_REFERER\'] : $modx->makeURL($modx->resource->get(\'id\'),\'\',\'\',\'abs\')),0);
        exit;
    }

}

//добавление стилей и скриптов в <head>, если нужно
$headHtml = "";

if(!empty($scriptProperties[\'style\'])){
    $modx->regClientCSS(SHOPKEEPER_ASSETS_URL."css/web/".$modx->getOption(\'style\',$scriptProperties,\'default\')."/style.css");
}

if(!$modx->getOption(\'noJavaScript\',$scriptProperties,false)){
    
    if(!$modx->getOption(\'noJQuery\',$scriptProperties,false)){
        $modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/jquery-1.8.2.min.js");
    }
    
    //$modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/jquery.livequery.js");
    $modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/lang/{$lang}.js?v=".$shopCart->version);
    $modx->regClientStartupScript(SHOPKEEPER_ASSETS_URL."js/web/shopkeeper.js?v=".$shopCart->version);
    
    $headHtml .= \'
    <script type="text/javascript">\';
      
    if($modx->getOption(\'noConflict\',$scriptProperties,false)){$headHtml .= "
        jQuery.noConflict();";
    }
    
    list($price_total,$items_total,$items_unique_total) = $shopCart->getTotal();
    
    $headHtml .= "
    var site_base_url = \'".$modx->config[\'base_url\']."\';
    var shkOpt = jQuery.extend(shkOptDefault,{";
    $headHtml .= "prodCont:\'".$scriptProperties[\'prodCont\']."\'";
    if($modx->getOption(\'lang\',$scriptProperties,null)!=\'ru\') $headHtml .= ", lang:\'".$scriptProperties[\'lang\']."\'";
    if($modx->getOption(\'currency\',$scriptProperties,null)!=\'руб.\') $headHtml .= ", currency: \'".$scriptProperties[\'currency\']."\'";
    $headHtml .= ", orderFormPage:\'".$modx->getOption(\'orderFormPage\',$scriptProperties,1)."\'";
    $headHtml .= ", orderFormPageUrl:\'".$modx->makeUrl($modx->getOption(\'orderFormPage\',$scriptProperties,0),\'\',\'\',\'abs\')."\'";
    if($modx->getOption(\'counterField\',$scriptProperties,null)==true) $headHtml .= ", counterField:true";
    if($modx->getOption(\'counterFieldCart\',$scriptProperties,null)==true) $headHtml .= ", counterFieldCart:true";
    if($scriptProperties[\'changePrice\']) $headHtml .= ", changePrice:".($scriptProperties[\'changePrice\']==\'replace\' ? "\'replace\'" : \'true\');
    if($modx->getOption(\'noCounter\',$scriptProperties,null)==true) $headHtml .= ", noCounter:true";
    if($modx->getOption(\'flyToCart\',$scriptProperties,null)!=\'helper\') $headHtml .= ", flyToCart:\'".$scriptProperties[\'flyToCart\']."\'";
    if($modx->getOption(\'style\',$scriptProperties,null)!=\'default\') $headHtml .= ", style:\'".$scriptProperties[\'style\']."\'";
    if($modx->getOption(\'noLoader\',$scriptProperties,null)==true) $headHtml .= ", noLoader:true";
    if($modx->getOption(\'allowFloatCount\',$scriptProperties,null)==true) $headHtml .= ", allowFloatCount:true";
    if($modx->getOption(\'animCart\',$scriptProperties,null)==false) $headHtml .= ", animCart:false";
    if($modx->getOption(\'goToOrderFormPage\',$scriptProperties,null)!=false) $headHtml .= ", goToOrderFormPage:true";
    if($debug) $headHtml .= ", debug:true";
    $headHtml .= ", psn:\'".$shopCart->encrypt($propertySetName)."\'";
    
    if(!empty($scriptProperties[\'cartHelperTpl\'])){
        $helperChunk = $shopCart->getChunk($scriptProperties[\'cartHelperTpl\']);
        $helperChunk_arr = preg_split("/[\\r\\n]+/", trim($helperChunk->get(\'snippet\')));
        $helperStr = \'\';
        for($i=0;$i<count($helperChunk_arr);$i++){
            $helperStr .= ($i>0 ? \'+\' : \'\')."\'".str_replace("\'","\\\'",trim($helperChunk_arr[$i]))."\'\\n";
        }
        $headHtml .= "\\n, shkHelper:{$helperStr}";
    }
  
    $headHtml .= "});
    SHK.data = {price_total:{$price_total}, items_total:{$items_total}, items_unique_total:{$items_unique_total}, ids:[".$shopCart->getProdIds(\'string\')."]};
    jQuery(document).bind(\'ready\',function(){
        jQuery(shkOpt.prodCont).shopkeeper();
    });";
    
    $headHtml .= "
    </script>";
    
    $modx->regClientStartupHTMLBlock($headHtml);
    
}

//вывод корзины
$output .= $shopCart->getCartContent();

//Вывод отладочной информации
if($debug){
    $curSavedP = !empty($_SESSION[\'shk_purchases\']) ? $_SESSION[\'shk_purchases\'] : array();
    $curSavedA = !empty($_SESSION[\'shk_addit_params\']) ? $_SESSION[\'shk_addit_params\'] : array();
    $output .= \'<pre>\'.print_r($curSavedP,true).print_r($curSavedA,true).\'</pre>\';
}

return $output;',
        ),
        'policies' => 
        array (
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modTemplateVar' => 
    array (
    ),
  ),
);