<?php
define('MODX_CORE_PATH', '/home/u316727/sonatel.ru/www/core/');
define('MODX_CONFIG_KEY', 'config');
?>