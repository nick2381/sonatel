<?php

echo $base->getHtmlHead(
array(
'nameTop'=>'�������� ��������',
'body'=>'style="padding:0px;padding-top:20px;margin:0px;overflow:hidden" marginheight="0" marginwidth="0"',
'menu'=>true
)
);

echo '<table cellspacing=0 cellpadding=0 border=0 width="100%" height="100%"><tr>
<td width=50%><iframe width="100%" height="100%" style=border:none;filter:none; frameborder=0 src="?core_fn=_global.file_manager.panel.php&frame=left" name=left scrolling=auto></iframe></td>
<td width=50%><iframe width="100%" height="100%" style=border:none;filter:none; frameborder=0 src="?core_fn=_global.file_manager.panel.php&frame=right" name=right scrolling=auto></iframe>
</tr></table>
</body></html>';

?>