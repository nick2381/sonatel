<?php

require_once($config['core_currentDirectory'].'/function.php');
findAndRunCommandDeleteTable();

$nameTable=$base->getRequest('nameTable','sql');
$command=$base->getRequest('command');
$var1=$base->getRequest('var1');
$var2=$base->getRequest('var2');

$sorting=$base->getRequest('sorting');
$desc=$base->getRequest('desc');
	if($command==='setSorting'){
		if($sorting===$var1){
			if($desc==='true'){$desc='false';}else{$desc='true';}
		}
	$sorting=$var1;
	}

	// ----------------------------------------------------------------------------
	// ��������� sql ������
	if($command==='sqlQuery'){
		if(@$db->sql_query($base->getRequest('sqlQuery','HTMLopen'))){
		$count=intval(@$db->sql_affectedrows());
		$base->setReport('<b>������� SQL ���������.</b><br>����� ���� ������������� �����: <b>'.$count.'</b> (�������� ������: '.memory_get_peak_usage(true).')');
		$base->saveLog('������ ������� SQL: '.$base->getRequest('sqlQuery','HTMLopen'));
		}else{
		$base->setReport('<b>������ ���������� SQL �������.</b><br>'.$db->sql_error(),'red');
		}
	
	}

list($info,$structure)=getInfoAndStructure($nameTable); // �������� ��� ���������� � ������� (���� ��� ��������)
getRightTopHtml($nameTable,$info,$structure,'��������');

$html='<input type=hidden name=nameWindow value="right_view.php">';

$html.='<input type=hidden name=sorting value="'.$sorting.'">
<input type=hidden name=desc value="'.$desc.'">';

// ---------------------------------------------------------------------------------
// ������� ���������� �������

	function printSearchButton($i){
	global $structure,$base;
	$html='���� <select name=searchCol_'.$i.' style=width:130>';
		foreach($structure as $col){
		$html.='<option value="'.$col['name'].'"';
			if($base->getRequest('searchCol_'.$i)===$col['name']){$html.=' selected';}
		$html.='>'.$col['name'];
		}
	$m=array('=','��������','!=','>','<','>=','<=');
	$html.='</select> <select name=searchType_'.$i.'>';
		foreach($m as $j){
		$html.='<option value="'.$j.'"';
			if($j===$base->getRequest('searchType_'.$i,'HTMLopen')){$html.=' selected';}
		$html.='>'.$j;
		}
	$html.='</select> <input style=width:350 name=searchText_'.$i.' value="'.$base->getRequest('searchText_'.$i,'html').'">';
	return $html;
	}

$html.='
<div id=divList style=padding-top:6;padding-bottom:6>
<script>

	function selectSql(flag){
	var v=""
		if(flag=="INSERT"){
		v="INSERT INTO '.$nameTable.' (';
		$m=array();foreach($structure as $col){$m[]=$col['name'];}$html.=join(',',$m);
		$html.=') VALUES (';
		$m=array();
			foreach($structure as $col){
				if($col['default']!==''){
				$m[]=htmlspecialchars($col['default']);
				}else{
					if($col['type']==='INT' || 
					$col['type']==='SMALLINT' || 
					$col['type']==='TINYINT' || 
					$col['type']==='NUMERIC' || 
					$col['type']==='DECIMAL' || 
					$col['type']==='FLOAT'){
					$m[]="'0'";
					}else{
					$m[]="''";
					}
				}
			}
		$html.=join(',',$m);
		$html.=')"
		}
		if(flag=="UPDATE"){
		v="UPDATE '.$nameTable.' SET  WHERE id="
		}
		if(flag=="DELETE"){
		v="DELETE FROM '.$nameTable.' WHERE id="
		}
	document.all.sqlQuery.value=v
	document.all.sqlSelect.value=""
	}

	function onPage(i){
	document.all.page.value=i
	onCommand("","")
	}

</script>';

$html.=printSearchButton(1);
$html.='<br><select name=else2><option value="AND">AND<option value="OR"';
	if($base->getRequest('else2')==='OR'){$html.=' selected';}
$html.= '>OR</select>&nbsp;&nbsp;&nbsp;';
$html.=printSearchButton(2);
$html.='<br><select name=else3><option value="AND">AND<option value="OR"';
	if($base->getRequest('else3')==='OR'){$html.=' selected';}
$html.= '>OR</select>&nbsp;&nbsp;&nbsp;';
$html.=printSearchButton(3);
$html.='</td></tr></table>';

$where=array();
$countWhere=0;
	for($i=1;$i<4;++$i){
		if($base->getRequest('searchText_'.$i)!==''){
			if($i>1 && $countWhere>0){
			$where[]=$base->getRequest('else'.$i,'HTMLopen');
			}
			if($base->getRequest('searchType_'.$i)==='��������'){
			$where[]=$base->getRequest('searchCol_'.$i)." LIKE '%".$base->getRequest('searchText_'.$i,'sql,HTMLopen')."%'";
			}else{
			$where[]=$base->getRequest('searchCol_'.$i).$base->getRequest('searchType_'.$i,'sql,HTMLopen')."'".$base->getRequest('searchText_'.$i,'sql,HTMLopen')."'";
			}
		++$countWhere;
		}
	}
	if(count($where)>0){$where=' WHERE '.join(' ',$where);}
	else{$where='';}

$result=@$db->sql_query("SELECT count(*) FROM ".$nameTable.$where);
//echo "SELECT count(*) FROM ".$nameTable.$where;
$line=$db->sql_fetchrow($result);
$total=$line[0];

$html.='<style>
.page {BORDER: #000000 1px solid;font-size:12px;width:25;text-align:center;cursor:hand;}
.c {color:blue;}
.b {vertical-align:top;}
</style>

<table border=0 width=100%><tr><td>

<table><tr><td>�����: <b style=font-size:16px;color:blue>'.getFormatVar($total).'</b></td>';

$countInPage=$base->getRequest('countInPage','int');if($countInPage==0){$countInPage=15;}
$countSymbol=$base->getRequest('countSymbol','int');if($countSymbol==0){$countSymbol=50;}

$page=$base->getRequest('page','int');

$p=intval($total/$countInPage);if(($p*$countInPage)<$total){$p++;}
	if($page>$p){$page=1;}
	// ���� �������� �� �������, ������ ���������� ���������
	if($page<1){$page=$p;}
	if($page<1){$page=1;}
$html.='<input type=hidden name=page value="'.$page.'">';
	
	if($p>1){
	$html.='<td>&nbsp;&nbsp;&nbsp;��������: </td>';
	$flag=false;
		for($i=1;$i<=$p;++$i){
			if($i<4 || ($i>($page-3) && $i<($page+3)) || $i>($p-3) || $p<11){
			$flag=false;
			$color='#dddddd';
				if($page==$i){$color='#aaff9d';}
			$html.='<td class=page onMouseOver=\'javaScript:this.style.background="';
				if($page==$i){$html.='#aaff9d';}else{$html.='#f2f2f2';}
			$html.='"\' onMouseOut=\'javaScript:this.style.background="'.$color.'"\' onClick=onPage('.$i.') style="background:'.$color.'">'.$i.'</td>';
			}else{
				if($flag==false){
				$html.='<td>...</td>';
				}
			$flag=true;
			}
		}
	}

$html.='</table>

</td><td align=right>';

$m=array(1,3,5,10,15,25,50,100,500,1000,10000,100000,1000000,10000000);
$html.='�����: <select name=countInPage>';
	foreach($m as $i){
	$j=$i;
		if($j>=1000){$j=$j/1000;if($j>=1000){$j=$j/1000;$j.='�';}else{$j.='�';}}
	$html.='<option value='.$i;
		if($i==$countInPage){$html.=' selected';}
	$html.='>'.$j;
	}
$html.='</select>

C�������: <select name=countSymbol>';
	foreach($m as $i){
	$j=$i;
		if($j>=1000){$j=$j/1000;if($j>=1000){$j=$j/1000;$j.='�';}else{$j.='�';}}
	$html.='<option value='.$i;
		if($i==$countSymbol){$html.=' selected';}
	$html.='>'.$j;
	}
$html.='</select> <input type=submit value="��������">

</td></tr></table>

</div>

<script>

	function menuTable(name){
	var m=document.getElementsByTagName("div");
		for(n in m){
		var e=m[n]
			if(e && e.id && e.id.substr(0,5)=="menu_"){
			var v=e.style.display
				if(v!="none"){
				v="none"
				}else{
					if(e.id==name){
					v="block"
					}
				}
			e.style.display=v
			}
		}
	}

	function setStatus(name,value){
		if(value=="hideAll" || value=="viewAll"){
		var m=document.getElementsByTagName("input");
			for(n in m){
			var e=m[n]
				if(n && n.substr(0,7)=="status_"){
					if(value=="hideAll"){
					e.value="hide"
					}else{
					e.value="text"
					}
				}
			}
		}else{
		e=document.getElementById("status_"+name)
			if(e){
			e.value=value
			}
		}
	document.getElementById("menu_"+name).style.display="none"
	}

</script>';

	if($sorting!==''){$where.=' ORDER BY '.$sorting;}
	if($desc==='true'){$where.=' DESC';}
$sql="SELECT * FROM ".$nameTable.$where." LIMIT ".(($page-1)*$countInPage).",".$countInPage;

$html.='
<style>
#tab td {
border-left:0px;
border-right:1px solid #ccc;
border-top:0px;
border-bottom:1px solid #ccc;
padding:4px;
margin:10px;
}
</style>
<table border=1 bordercolor=#cccccc cellspacing=0 cellpadding=2 width=100% id=tab><tr bgcolor=#eeeeee>';
	foreach($structure as $col){
	$html.='<td align=center valign=top style=cursor:pointer onClick=\'menuTable("menu_'.$col['name'].'")\' title="'.$col['name'].'">
	<div style="width:100;display:none;position:absolute" align=left id="menu_'.$col['name'].'"\'><br><br><br>';
	$status=$base->getRequest('status_'.$col['name']);
		if($status===''){
		$status='text';
		}
	$html.='<input name=status_'.$col['name'].' type=hidden style=width:100 value="'.$status.'">
	
	<input type=button style=width:100 value="�����������" onclick=onCommand("setSorting","'.$col['name'].'")><br>
	<input type=button style=width:100 value="�����" onclick=setStatus("'.$col['name'].'","text")><br>
	<input type=button style=width:100 value="���� Y.m.d" onclick=setStatus("'.$col['name'].'","Y.m.d")><br>
	<input type=button style=width:100 value="���� Y.m.d H:i" onclick=setStatus("'.$col['name'].'","Y.m.d_H:i")><br>
	<input type=button style=width:100 value="������" onclick=setStatus("'.$col['name'].'","hide")>
	<input type=button style=width:100 value="������ ���" onclick=setStatus("'.$col['name'].'","hideAll")>
	<input type=button style=width:100 value="�������� ���" onclick=setStatus("'.$col['name'].'","viewAll")>
	</div>';
		if($base->getRequest('status_'.$col['name'])!=="hide"){
		$html.='<b>';
			if($sorting===$col['name']){$html.='<font style=font-size:16px color=blue>'.$col['name'].'</font>';}else{$html.=$col['name'];}
		$html.='</b><br>'.$col['type'].' ('.$col['length'].')<br>';
		$m=array();
			if($col['index']==='primary'){$m[]='P';}
			if($col['index']==='true'){$m[]='I';}
			if($col['index']==='unique'){$m[]='U';}
			if($col['auto']==='true'){$m[]='A';}
			if($col['null']==='true'){$m[]='NULL';}
			if(count($m)>0){
			$html.='<font style="font-family:Arial;color:red;font-size:11px">'.join($m,',').'</font>';
			}
		}else{
		$html.='<b class=c>.</b>';
		}
	$html.='</td>';
	}
$html.='</tr>';

	// ������� ��������� SQL ������
	if($command==='sqlQuery'){
	$s=$base->getRequest('sqlQuery');
		// ������ ���������� �� SELECT, ������ ��������� ������� � �������
		if(strtolower(substr($s,0,7))==='select '){
		$sql=$s;
		}
	}else{
	$s=$sql;
	}

echo '<table width=100% border=0><tr><td align=right>
	<table><tr><td><textarea style=width:550;height:65 name=sqlQuery>'.$s.'</textarea></td>
	<td>
	<select style=width:100 onchange=selectSql(this.value) id=sqlSelect><option value="">-<option value="INSERT">INSERT<option value="UPDATE">UPDATE<option value="DELETE">DELETE</select><br>
	<input type=button value="��������� SQL" style=width:100 onClick=onCommand("sqlQuery","")>
	</td></tr></table>

</td></tr><tr>
<td align=right>';

echo $html;

$result=@$db->sql_query($sql);
	while($line=$db->sql_fetchrow($result)){
	echo '<tr>';
		foreach($structure as $col){
		$txt=$line[$col['name']];
			if($base->getRequest('status_'.$col['name'])==="hide"){
			$txt='<b class=c>.</b>';
			}elseif($txt===NULL){
			$txt='<b style=color:blue>NULL</b>';
			}elseif($txt===''){
			$txt='&nbsp;';
			}elseif($base->getRequest('status_'.$col['name'])==="Y.m.d"){
			$txt=date('Y.m.d',intval($txt));
			}elseif($base->getRequest('status_'.$col['name'])==="Y.m.d_H:i"){
			$txt=date('Y.m.d H:i',intval($txt));
			}else{
				if(strlen($txt)>$countSymbol){$txt=htmlspecialchars(substr($txt,0,$countSymbol)).' <b class=c>>></b>';}
				else{$txt=htmlspecialchars($txt);}
			$txt=str_replace("\n\r",'<b style=color:blue>\n\r</b><br>',$txt);
			$txt=str_replace("\r\n",'<b style=color:blue>\r\n</b><br>',$txt);
			$txt=str_replace("\n",'<b style=color:blue>\n</b><br>',$txt);
			$txt=str_replace(chr(0),'<b style=color:red>\0</b>',$txt);
			}
		echo '<td>'.$txt.'</td>';
		}
	echo '</tr>';
	}
echo '</table>
</form>';

?>
