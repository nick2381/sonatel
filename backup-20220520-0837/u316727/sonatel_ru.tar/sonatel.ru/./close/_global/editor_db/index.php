<?php

echo $base->getHtmlHead(
array(
'nameTop'=>'�������� ��',
'body'=>'style="padding:0px;margin:0px;overflow:hidden" marginheight="0" marginwidth="0"',
'menu'=>true
)
);

echo '<table cellspacing=0 cellpadding=0 border=0 width=100% height=100%>
<td id=t_left style="border-right:1px solid #000" width=280><iframe width=100% height="100%" src="?core_fn='.$config['core_currentUrl'].'.left.php" id=left frameborder=0></iframe></td>
<td id=t_right><iframe width=100% height="100%" src="" id=right frameborder=0 ></iframe></td></tr>
</table>
</body></html>';

?>
