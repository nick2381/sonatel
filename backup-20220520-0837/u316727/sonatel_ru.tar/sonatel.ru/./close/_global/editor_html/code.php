<html><head><META HTTP-EQUIV="Content-Type" CONTENT="text/html;CHARSET=Windows-1251">
<title>SORIUS | ������� - ���������� �������� HTML</title>
<STYLE>
a:link{font-size:11px;font-family:Arial;color:#330066!important;text-decoration:none}
a:visited{font-size:11px;font-family:Arial;color:#330066!important;text-decoration:none}
a:hover{font-size:11px;font-family:Arial;color:#3300ff!important;text-decoration:none}
a:active{font-size:11px;font-family:Arial;color:#3300ff!important;text-decoration:none}
td{font-size:11px;FONT-FAMILY:Arial;color:#330066}
body{font-size:11px;FONT-FAMILY:Arial;color:#330066}
</STYLE>

<script>
var dd=window.opener.document;
var d=document;
var m;var i; var j; var k;
var a=new Array(931,9600,9604,9608,9612,9616,9617,9618,9619,9632,9642,9650,9658,9660,9668,9674,9679,9688,9689,9835,9829,9830,9827);

function sc(i){dd.frames.fVisual.focus();j=dd.frames.fVisual.document.selection.createRange();j.pasteHTML('&#'+i);self.close()}

function viv(i) {
d.all.prev1.innerHTML='&#'+i;
d.all.prev2.innerHTML='&#'+i;
}

function view_simvol() {
k=0;m=0;
d.write('<table cellpadding=1 cellspacing=0 border=1 style="cursor:hand" width=100% height=100%><tr>');
	for (i=126;i<(9581+a.length);++i) {
	j=0;
		if (i>125 && i<384){j=1}
		if (i>935 && i<975){j=1}
		if (i>9551 && i<9581){j=1}
		if (i==127 || i==129 || i==141 || i==143 || i==144 || i==157) {j=0}
		m=i;
		if (i>9580) {j=1;m=a[i-9581]}
		if (j==1) {
		++k;
			if (k==26) {k=1;d.write('</tr><tr>');}
		d.write('<td align=center onclick="sc('+m+')" onmouseover="viv('+m+')"><font style=font-size:16px>&#'+m+'</font></td>');
		}
	}
d.write('<td align=center colspan=7><a href="#" onClick="self.close()"><b>�����</b></a></td></tr></table>');
}

</script>
</head>
<body bgcolor="#D6D3CE"><div align="center">
<table width=100% height=100%>
<tr>
<td valign=top width=70>
<table width=60 height=60 border=1><tr><td bgcolor="#ffffff" align=center><font style="font-size:32px"><div id="prev1" name="prev1"></div></font></td></tr></table>
<table width=60 height=60 border=1><tr><td bgcolor="#ffffff" align=center><font style="font-size:32px"><b><div id="prev2" name="prev2"></div></b></font></td></tr></table>
</td>
<td><script>view_simvol()</script></td>
</tr>
</table>
</div></body></html>