<?php

echo $base->getHtmlHead(
array(
'nameTop'=>'������',
'body'=>'style="padding:0px;margin:0px;overflow:hidden" marginheight="0" marginwidth="0"',
'menu'=>true
)
);

echo '<table cellspacing=0 cellpadding=0 border=0 width=100% height=100% border=1px><tr><td width=860px style="border-right:1px solid #999"><iframe width=100% height="100%" marginheight=0 marginwidth=0 src="?core_fn='.$config['core_currentUrl'].'.edit.php" name=left frameborder=0 scrolling="auto"></iframe></td><td><iframe width=100% height="100%" marginheight=0 marginwidth=0 src="?core_fn='.$config['core_currentUrl'].'.menu.php" name=right frameborder=0></iframe></td></tr></table></body></html>';

?>