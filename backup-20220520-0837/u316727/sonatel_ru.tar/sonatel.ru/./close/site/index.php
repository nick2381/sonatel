<?php

echo $base->getHtmlHead(
array(
'nameTop'=>'�������� �����',
'body'=>'style="padding:0px;margin:0px;overflow:hidden" marginheight="0" marginwidth="0"',
'menu'=>true
)
);

echo '<table cellspacing=0 cellpadding=0 border=0 width=100% height=100% border=1>
<tr>
<td>&nbsp;</td>
<td width=350px style="border-right:1px solid #999"><iframe width=100% height="100%" marginheight=0 marginwidth=0 src="?core_fn='.$config['core_currentUrl'].'.menu.php" name=left frameborder=0 scrolling="yes"></iframe></td>
<td width=650px><iframe width=100% height="100%" marginheight=0 marginwidth=0 src="?core_fn='.$config['core_currentUrl'].'.edit.php" name=right frameborder=0 scrolling="yes"></iframe></td>
<td>&nbsp;</td>
</tr></table></body></html>';

?>