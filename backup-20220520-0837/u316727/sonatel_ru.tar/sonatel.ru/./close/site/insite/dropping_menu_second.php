<?php

$lineTop=explode(',',''.$object['var']['lineTop']);
$lineDown=explode(',',''.$object['var']['lineDown']);

$db=$base->connectDataBase();

$m=array_merge ($lineTop, $lineDown);
$m=array_unique($m);

$sql='';
	foreach($m as $id){
		if($sql!==''){
		$sql.=" OR ";
		}
	$sql.="parent=".$id." OR id=".$id."";
	}

$next_in_dir=array();
$next_on_level=array();
$tree=array();

$sql="SELECT id,parent,parent_list,overhead,dir,status,name,path_url,redirect FROM ".$config['site_table_page']." WHERE ".$sql.'';
	if($result=$db->sql_query($sql)){
		while($line=$db->sql_fetchrow($result)){
			if($line['id']==1215 || $line['id']==1077 || $line['id']==946){
			$line['name']='<font color=red>'.$line['name'].'</font>';
			}
			if($line['overhead']==0){
			$next_in_dir[$line['parent']]=$line['id'];
			}else{
			$next_on_level[$line['overhead']]=$line['id'];
			}
		$tree[$line['id']]=$line;
		}
	}else{
	$html.='������ ���� ������';
	}

function printLineTopMenu($array){
global $tree,$html,$next_in_dir,$next_on_level,$config;
$count=0;
	foreach($array as $id){
	++$count;
	
	$html.='<li><a href="http://'.$config['core_host'].'/'.$tree[$id]['path_url'].'/"';
		if($count==1){$html.=' style="border:0px"';}
	$html.='>'.$tree[$id]['name'].'</a><!-- [if IE lt 6]><div style="width:0px;height:0px;float:left;"></div><![endif] -->
	<ul class="submenu">';
	// <br><img src="http://www.mnepu.ru/img/design/point2.gif" style=padding-top:8px border=0>
	$id_child=$next_in_dir[$id];
		while(isset($tree[$id_child]) && $id_child>0){
		
		// ���� ���� ��������, �� ���������, ��������� ��� � ����� ���� ��� ���
		$redirect=$tree[$id_child]['redirect'];
		$url='http://'.$config['core_host'].'/'.$tree[$id_child]['path_url'].'/';
		$target='';
			if($redirect!==''){
				if(strpos($redirect,'http:')!==false){
				$m=explode('|',$redirect);
					if(count($m)>1){
						if($m[0]===''){
						$target=' target="_blank"';
						}else{
						$target=' target="'.$m[0].'"';
						}
						if($m[1]!==''){
						$url=$m[1];
						}
					}else{
					$url=$redirect;
					}
				}
			}
		
			if($tree[$id_child]['status']==1){
			$html.='<li><a href="'.$url.'"'.$target.'>'.$tree[$id_child]['name'].'</a></li>';
			}
			if(isset($next_on_level[$id_child])){
			$id_child=$next_on_level[$id_child];
			}else{
			$id_child=0;
			}
		}
	$html.='</ul></li>';
	}
}

$html.='<div id="menu">
<ul class="menu">';
printLineTopMenu($lineTop);
$html.='</ul>
</div>';
$html.='<div id="menuB" style=clear:left>
<UL class="menuB">';
printLineTopMenu($lineDown);
$html.='</UL>
</div>';

?>