<?php

// ����� ���������� ���� ��������
$id_parent_news_all=105; // ID ����� �� ����� ���������

$html='<table cellspacing=0px cellpadding=0px border=0>';

$sql="SELECT
i.id,
i.id_list,
i.date,
i.robots,
i.flag,
t.name_small,
t.name_big,
t.text_small,
t.text_big,
t.block,
c.name as config_name
FROM ".$config['list_table_index']." as i
LEFT JOIN ".$config['list_table_config']." as c ON c.parent=".$id_parent_news_all." AND c.status>0 AND i.id_list=c.id
LEFT JOIN ".$config['list_table_text']." as t ON i.id=t.id_element WHERE i.display=1 AND i.flag=0 ORDER BY date DESC LIMIT 0,12";

	if($result=$db->sql_query($sql)){
		while($line=$db->sql_fetchrow($result)){
		$m=explode('|',$line['block']);
			for($i=1;$i<count($m);$i+=2){
			$line[$m[$i-1]]=$m[$i];
			}
		$aBody=' href="http://www.mnepu.ru/press_center/news/?id='.$line['id'].'"';
			if(intval(@$line['robots'])==0){$aBody.=' rel="nofollow"';}
		$html.='<tr><td style="padding:10px;padding-top:2px;">';
		$html.='<div style="color:#515151;font-size:10px">'.date('Y.m.d',$line['date']).' - '.$line['config_name'].'</div>';
			if(intval(@$line['robots'])==0){$html.='<noindex>';}
		$html.='<a'.$aBody.' style="color:#212123;font-size:14px">'.$line['name_small'].'</a>';
			if(intval(@$line['robots'])==0){$html.='</noindex>';}
		$text=substr(strip_tags($line['text_big']),0,200);
		$m=explode(' ',$text);
			if(count($m)>2){
			unset($m[count($m)-1]);
			}
		$text=join($m,' ');
		$html.='<p style="margin-top:5px;margin-bottom:20px;color:#7d8472;font-size:11px">'.$text.' ...<a'.$aBody.'></p></td></tr>';
		}
	}

$html.='</table>';



?>

