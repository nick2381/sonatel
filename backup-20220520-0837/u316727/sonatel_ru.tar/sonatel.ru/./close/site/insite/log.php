<?php

$db=$base->connectDataBase();

	if($db){
	
	list($y,$m,$d)=explode('.',date('Y.m.d',time()-(((60*60)*24)*7) ));
	$timeFrom=mktime(0,0,1,$m,$d,$y);
	list($y,$m,$d)=explode('.',date('Y.m.d',time()));
	$timeTo=mktime(23,59,59,$m,$d,$y);
	
	$sql="SELECT * FROM mnepu_core_log WHERE date_create>".$timeFrom." AND date_create<".$timeTo." ORDER BY date_create DESC";
		if($result=$db->sql_query($sql)){
		$oldDate=0;
			while($line=$db->sql_fetchrow($result)){
			$newDate=date('d',$line['date_create']);
				if($newDate!=$oldDate){
				$html.='<hr>'.date('d.m.Y',$line['date_create']).'<br><br>';
				}
			$html.='<div style=margin-bottom:10px><font color=#666666>';
				if($line['type']==0){
				$html.='������: ';
				}
				if($line['type']==1){
				$html.='�������: ';
				}
				if($line['type']==2){
				$html.='�������: ';
				}
				if($line['type']==3){
				$html.='��������: ';
				}
			$html.=' '.$line['name_group'].'</font><br>';
				if($line['name_group']=='�������� �����'){
				$html.='<a href="'.$base->getUrlPage('',true,$line['id_element']).'" style=font-size:14px>'.$line['name_element'].'</a>';
				}else if($line['name_group']=='�������� �����'){
				//$html.='<a href="http://www.mnepu.ru/fl/'.$line['id_group'].'/">'.$line['name_element'].'</a>';
				}else{
				$html.='<font style=font-size:14px>'.$line['name_element'].'</font>';
				}
			$html.='</div>';
			$oldDate=$newDate;
			}
		}else{
		$html.='<font color="#FF0000">������ SQL �������</font>';
		}
	
	}

?>

