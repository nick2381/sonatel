<?php

$lineTop=explode(',',''.$object['var']['lineTop']);
$lineDown=explode(',',''.$object['var']['lineDown']);

$db=$base->connectDataBase();

$m=array_merge ($lineTop, $lineDown);
$m=array_unique($m);

$sql='';
	foreach($m as $id){
		if($sql!==''){
		$sql.=" OR ";
		}
	$sql.="parent=".$id." OR id=".$id."";
	}

$next_in_dir=array();
$next_on_level=array();
$tree=array();

$sql="SELECT id,parent,parent_list,overhead,dir,status,name,path_url FROM ".$config['site_table_page']." WHERE ".$sql.'';
	if($result=$db->sql_query($sql)){
		while($line=$db->sql_fetchrow($result)){
			if($line['id']==1215 || $line['id']==1077 || $line['id']==946){
			$line['name']='<font color=red>'.$line['name'].'</font>';
			}
			if($line['overhead']==0){
			$next_in_dir[$line['parent']]=$line['id'];
			}else{
			$next_on_level[$line['overhead']]=$line['id'];
			}
		$tree[$line['id']]=$line;
		}
	}else{
	$html.='������ ���� ������';
	}

$html.='<div class="main-menu">';

$html.='<table cellspacing=0 cellpadding=0 border=0 align=center><tr><td>';

$maxColumn=4;

function printLineTopMenu($array){
global $tree,$html,$next_in_dir,$next_on_level,$config;
	foreach($array as $id){
	$count=0;
	$htm_hidden='';
	$htm_short='';
	$html.='<div class="group-items">';
	$id_child=$next_in_dir[$id];
		while(isset($tree[$id_child]) && $id_child>0){
			if($tree[$id_child]['status']==1){
			
			// ���� ���� ��������, �� ���������, ��������� ��� � ����� ���� ��� ���
			$redirect=$tree[$id]['redirect'];
			$url='http://'.$config['core_host'].'/'.$tree[$id_child]['path_url'].'/';
			$target='';
				if($redirect!==''){
					if(strpos($redirect,'http:')!==false){
					$m=explode('|',$redirect);
						if(count($m)>1){
							if($m[0]===''){
							$target=' target="_blank"';
							}else{
							$target=' target="'.$m[0].'"';
							}
							if($m[1]!==''){
							$url=$m[1];
							}
						}else{
						$url=$redirect;
						}
					}
				}
			
				if($count>0){
					if($count<$maxColumn){
					$htm_short.='<hr>';
					}
				$htm_hidden.='<hr>';
				}
				if($count<$maxColumn){
				$htm_short.='<A href="'.$url.'"'.$target.'>'.$tree[$id_child]['name'].'</A>'."\n";
				}
			$htm_hidden.='<A href="'.$url.'"'.$target.'>'.$tree[$id_child]['name'].'</A>'."\n";
			}
			if(isset($next_on_level[$id_child])){
			$id_child=$next_on_level[$id_child];
			}else{
			$id_child=0;
			}
		++$count;
		}
	$html.='
	<div class="inner hidden" style="margin-top:58px">
		<div class="item-1-childs"><noindex>'.$htm_hidden.'</noindex></div>
	</div>
	<div class="inner short">
		<div class="item-1 is-full"><table cellspacing=0 cellpadding=0><tr><td align=left>';
		$headName=str_replace('International programs','International<br>programs',$tree[$id]['name']);
		$headName=str_replace('��������� � �������','���������&nbsp;�<br>�������',$headName);
		$html.='<b><A href="http://'.$config['core_host'].'/'.$tree[$id]['path_url'].'/">'.$headName.'</A><img src="http://'.$config['core_host'].'/img/design/point.gif" style="margin-left:0px" alt="" vspace="0" hspace="0"></b>';
		$html.='
		</td></tr></table>
		</div>';
	$html.='</div>
	</div>';
	}
}

printLineTopMenu($lineTop);
printLineTopMenu($lineDown);

$html.='</td></tr></table>';
$html.='</div>';

?>