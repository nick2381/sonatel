<?php

$startId=intval($object['var']['startId']);

$db=$base->connectDB();


$menu=array();
$child=array();

// ���� ��������
$sql="SELECT id,parent,position,level,status,dir,name,path_url,redirect FROM ".$config['site_table_page']." WHERE id=".$startId;
	if($result=$db->sql_query($sql)){
		// �������� ������
		if($source=$db->sql_fetchrow($result)){
		// ������ ���� ����� ��������� �� 2 ������ �����������
		$sql="SELECT id,parent,position,level,status,dir,name,path_url,redirect FROM ".$config['site_table_page']." WHERE status=1 AND level<".($source['level']+3)." AND path LIKE '%-".$startId."-%' ORDER BY position";
			if($result=$db->sql_query($sql)){
				while($line=$db->sql_fetchrow($result)){
					if($line['level']==($source['level']+1)){
					$menu[$line['id']]=$line;
					}else{
					$child[$line['parent']][]=$line;
					}
				}
			}
		
		}
	}


	if(count($menu)>0){
	$html.='<DIV class=top_nav><UL id=horizontal-multilevel-menu>'."\n";
		foreach($menu as $id=>$line){
		$url=$base->getUrlPage('',false,$id,$line['path_url']);
		$html.='<LI><A href="'.$url.'"><b style=font-size:14px>'.$line['name'].'</b></A>'."\n";
			if(isset($child[$id]) && count($child[$line['id']])>0){
			$html.='<UL class=sub>'."\n";
				foreach($child[$id] as $parent=>$line){
				$url=$base->getUrlPage('',false,$line['id'],$line['path_url']);
				$html.='<LI class=subli><A href="'.$url.'">'.$line['name'].'</A></LI>'."\n";
				}
			$html.='</UL>'."\n";
			}
		$html.='</LI>'."\n";
		}
	$html.='</UL></div>';
	}



$startId=901;

$menu=array();
$child=array();

// ���� ��������
$sql="SELECT id,parent,position,level,status,dir,name,path_url,redirect FROM ".$config['site_table_page']." WHERE id=".$startId;
	if($result=$db->sql_query($sql)){
		// �������� ������
		if($source=$db->sql_fetchrow($result)){
		// ������ ���� ����� ��������� �� 2 ������ �����������
		$sql="SELECT id,parent,position,level,status,dir,name,path_url,redirect FROM ".$config['site_table_page']." WHERE status=1 AND level<".($source['level']+3)." AND path LIKE '%-".$startId."-%' ORDER BY position";
			if($result=$db->sql_query($sql)){
				while($line=$db->sql_fetchrow($result)){
					if($line['level']==($source['level']+1)){
					$menu[$line['id']]=$line;
					}else{
					$child[$line['parent']][]=$line;
					}
				}
			}
		
		}
	}


	if(count($menu)>0){
	$html.='<DIV class=top_nav style=background:#079d00><UL id=horizontal-multilevel-menu>'."\n";
		foreach($menu as $id=>$line){
		$url=$base->getUrlPage('',false,$id,$line['path_url']);
		$html.='<LI><A href="'.$url.'">'.$line['name'].'</A>'."\n";
			if(isset($child[$id]) && count($child[$line['id']])>0){
			$html.='<UL class=sub>'."\n";
				foreach($child[$id] as $parent=>$line){
				$url=$base->getUrlPage('',false,$line['id'],$line['path_url']);
				$html.='<LI class=subli><A href="'.$url.'">'.$line['name'].'</A></LI>'."\n";
				}
			$html.='</UL>'."\n";
			}
		$html.='</LI>'."\n";
		}
	$html.='</UL></div>';
	}

/*

<UL id=horizontal-multilevel-menu>

	<LI><A href="ob_akademii/">?? ????????</A>
	
	<UL class=sub>
	<LI class=subli><A	href="management.php">???????????</A></LI>
	<LI class=subli><A	href="docuch.php">?????????????	?????????</A></LI>
	<LI class=subli><A	href="rating.php">??????? ????????</A></LI>
	</UL>

	</li>

</ul>

*/


?>