<?php

echo $base->getHtmlHead(
array(
'nameTop'=>'�������',
'body'=>'style="padding:0px;margin:0px;overflow:hidden" marginheight="0" marginwidth="0"',
'menu'=>true
)
);

echo '<table cellspacing=0 cellpadding=0 border=0 width=100% height=100%><tr><td width=650px style="border-right:1px solid #999"><iframe width=100% height="100%" marginheight=0 marginwidth=0 src="?core_fn='.$config['core_currentUrl'].'.nav.php" name=levo frameborder=0 scrolling="yes"></iframe></td><td><iframe width=100% height="100%" marginheight=0 marginwidth=0 src="?core_fn='.$config['core_currentUrl'].'.edit.php" name=pravo frameborder=0 scrolling="yes"></iframe></td></tr></table></body></html>';

?>