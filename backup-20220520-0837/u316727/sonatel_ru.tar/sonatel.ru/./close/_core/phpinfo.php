<?php

echo $base->getHtmlHead(
array(
'menu'=>true
)
);
phpinfo();

?>