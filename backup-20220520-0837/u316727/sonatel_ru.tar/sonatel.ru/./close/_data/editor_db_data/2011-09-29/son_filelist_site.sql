-- info

name=son_filelist_site
comment=
update=2011.09.29 - 15:14
sqlLayer=mysql
group=
count=28

-- cols

name=id
comment=
null=false
default=
auto=true
type=INT
length=11
index=primary

name=id_list
comment=
null=false
default=
auto=false
type=INT
length=11
index=false

name=id_group
comment=
null=false
default=
auto=false
type=INT
length=11
index=false

name=name_original
comment=
null=false
default=
auto=false
type=VARCHAR
length=255
index=false

name=name_new
comment=
null=false
default=
auto=false
type=VARCHAR
length=255
index=false

name=exp
comment=
null=false
default=
auto=false
type=VARCHAR
length=6
index=false

name=size
comment=
null=false
default=
auto=false
type=INT
length=11
index=false

name=date_create
comment=
null=false
default=
auto=false
type=INT
length=11
index=false

name=text_info
comment=
null=false
default=
auto=false
type=TEXT
length=0
index=false

-- data

6|1|14|tech3|tech3|jpg|9163|1316945263|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#19163#1ix#1100#1iy#176#1is#13115#1sx#1250#1sy#1190#1ss#110035#1mx#10#1my#10#1bx#1722#1by#1550#1bs#150585#1
7|1|14|tech4|tech4|jpg|8444|1316945693|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#18444#1ix#1100#1iy#176#1is#13022#1sx#1250#1sy#1190#1ss#19049#1mx#10#1my#10#1bx#1722#1by#1550#1bs#144423#1
5|1|14|tech2|tech2|jpg|12360|1316945238|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#112360#1ix#1100#1iy#176#1is#13631#1sx#1250#1sy#1190#1ss#112550#1mx#10#1my#10#1bx#1722#1by#1550#1bs#163610#1
4|1|14|tech1|tech1|jpg|10072|1316945197|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#110072#1ix#1100#1iy#176#1is#13177#1sx#1250#1sy#1190#1ss#111290#1mx#10#1my#10#1bx#1722#1by#1550#1bs#157725#1
8|1|14|tech5_1|tech5_1|jpg|10144|1316945701|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#110144#1ix#1100#1iy#176#1is#13185#1sx#1250#1sy#1190#1ss#110868#1mx#10#1my#10#1bx#1722#1by#1550#1bs#154512#1
9|1|14|tech5_2|tech5_2|jpg|12830|1316945713|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#112830#1ix#1100#1iy#176#1is#13722#1sx#1250#1sy#1190#1ss#113449#1mx#10#1my#10#1bx#1722#1by#1550#1bs#170089#1
10|1|14|tech6|tech6|jpg|7387|1316945750|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#17387#1ix#1100#1iy#176#1is#12884#1sx#1250#1sy#1190#1ss#18741#1mx#10#1my#10#1bx#1722#1by#1550#1bs#142818#1
11|1|14|tech7|tech7|jpg|9182|1316945759|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#19182#1ix#1100#1iy#176#1is#12537#1sx#1250#1sy#1190#1ss#19167#1mx#10#1my#10#1bx#1722#1by#1550#1bs#145801#1
12|1|14|tech8|tech8|jpg|8455|1316945767|login#1phpbox#1ip#195.26.192.238#1ox#1197#1oy#1150#1os#18455#1ix#1100#1iy#176#1is#12714#1sx#1250#1sy#1190#1ss#19476#1mx#10#1my#10#1bx#1722#1by#1550#1bs#146259#1
13|1|16|proezd2011|proezd2011|jpg|33100|1316947950|login#1phpbox#1ip#195.26.192.238#1ox#1350#1oy#1318#1os#133100#1ix#1100#1iy#190#1is#14353#1sx#1250#1sy#1227#1ss#117823#1mx#10#1my#10#1bx#1605#1by#1550#1bs#169241#1
14|1|17|tfile_pic1|tfile_pic1|jpg|3755|1316948452|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#13755#1ix#1100#1iy#1100#1is#12538#1sx#1250#1sy#1250#1ss#17216#1mx#10#1my#10#1bx#1550#1by#1550#1bs#123344#1
15|1|17|tfile_pic2|tfile_pic2|jpg|4888|1316948459|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#14888#1ix#1100#1iy#1100#1is#13104#1sx#1250#1sy#1250#1ss#19337#1mx#10#1my#10#1bx#1550#1by#1550#1bs#130167#1
16|1|17|tfile_pic3|tfile_pic3|jpg|4650|1316948466|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#14650#1ix#1100#1iy#1100#1is#12919#1sx#1250#1sy#1250#1ss#18798#1mx#10#1my#10#1bx#1550#1by#1550#1bs#128733#1
17|1|18|tfile_pic4|tfile_pic4|jpg|6118|1316948610|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#16118#1ix#1100#1iy#1100#1is#13567#1sx#1250#1sy#1250#1ss#111256#1mx#10#1my#10#1bx#1550#1by#1550#1bs#136805#1
18|1|18|tfile_pic5|tfile_pic5|jpg|3444|1316948618|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#13444#1ix#1100#1iy#1100#1is#12268#1sx#1250#1sy#1250#1ss#16170#1mx#10#1my#10#1bx#1550#1by#1550#1bs#119575#1
20|1|18|tfile_pic6|tfile_pic6|jpg|5320|1316948648|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#15320#1ix#1100#1iy#1100#1is#13157#1sx#1250#1sy#1250#1ss#19567#1mx#10#1my#10#1bx#1550#1by#1550#1bs#130740#1
21|1|19|tfile_pic7|tfile_pic7|jpg|4714|1316948742|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#14714#1ix#1100#1iy#1100#1is#12357#1sx#1250#1sy#1250#1ss#16960#1mx#10#1my#10#1bx#1550#1by#1550#1bs#122303#1
22|1|19|tfile_pic8|tfile_pic8|jpg|4159|1316948750|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#14159#1ix#1100#1iy#1100#1is#12144#1sx#1250#1sy#1250#1ss#16187#1mx#10#1my#10#1bx#1550#1by#1550#1bs#119655#1
23|1|19|tfile_pic9|tfile_pic9|jpg|4402|1316948759|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#14402#1ix#1100#1iy#1100#1is#12264#1sx#1250#1sy#1250#1ss#16440#1mx#10#1my#10#1bx#1550#1by#1550#1bs#120477#1
24|1|20|tfile_pic10|tfile_pic10|jpg|5926|1316948853|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1145#1os#15926#1ix#1100#1iy#196#1is#12680#1sx#1250#1sy#1241#1ss#18563#1mx#10#1my#10#1bx#1568#1by#1550#1bs#129770#1
25|1|20|tfile_pic11|tfile_pic11|jpg|5336|1316948859|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#15336#1ix#1100#1iy#1100#1is#12558#1sx#1250#1sy#1250#1ss#17620#1mx#10#1my#10#1bx#1550#1by#1550#1bs#124450#1
26|1|20|tfile_pic12|tfile_pic12|jpg|5437|1316948869|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#15437#1ix#1100#1iy#1100#1is#12678#1sx#1250#1sy#1250#1ss#17805#1mx#10#1my#10#1bx#1550#1by#1550#1bs#125321#1
27|1|21|tfile_pic13|tfile_pic13|jpg|6390|1316948933|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1143#1os#16390#1ix#1100#1iy#195#1is#13083#1sx#1250#1sy#1238#1ss#19552#1mx#10#1my#10#1bx#1576#1by#1550#1bs#133042#1
28|1|21|tfile_pic14|tfile_pic14|jpg|6374|1316948943|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1144#1os#16374#1ix#1100#1iy#196#1is#13046#1sx#1250#1sy#1240#1ss#19511#1mx#10#1my#10#1bx#1572#1by#1550#1bs#132832#1
29|1|21|tfile_pic15|tfile_pic15|jpg|5920|1316948951|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1150#1os#15920#1ix#1100#1iy#1100#1is#12970#1sx#1250#1sy#1250#1ss#18968#1mx#10#1my#10#1bx#1550#1by#1550#1bs#128961#1
30|1|22|tfile_pic18|tfile_pic18|jpg|8080|1316949032|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1114#1os#18080#1ix#1100#1iy#176#1is#13551#1sx#1250#1sy#1190#1ss#112397#1mx#10#1my#10#1bx#1723#1by#1550#1bs#161363#1
31|1|22|tfile_pic19|tfile_pic19|jpg|6610|1316949048|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1114#1os#16610#1ix#1100#1iy#176#1is#13234#1sx#1250#1sy#1190#1ss#110500#1mx#10#1my#10#1bx#1723#1by#1550#1bs#150830#1
32|1|22|tfile_pic20|tfile_pic20|jpg|6746|1316949065|login#1phpbox#1ip#195.26.192.238#1ox#1150#1oy#1114#1os#16746#1ix#1100#1iy#176#1is#13179#1sx#1250#1sy#1190#1ss#111242#1mx#10#1my#10#1bx#1723#1by#1550#1bs#157717#1
