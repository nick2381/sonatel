-- info

name=son_filelist_name
comment=
update=2011.09.29 - 15:14
sqlLayer=mysql
group=
count=1

-- cols

name=id
comment=
null=false
default=
auto=true
type=INT
length=11
index=primary

name=name
comment=
null=false
default=
auto=false
type=VARCHAR
length=255
index=false

name=name_table
comment=
null=false
default=
auto=false
type=VARCHAR
length=255
index=false

name=comment
comment=
null=false
default=
auto=false
type=VARCHAR
length=255
index=false

name=command
comment=
null=false
default=
auto=false
type=TEXT
length=0
index=false

-- data

1|site|off_filelist_site|����|original=1%2i_x=100%2s_x=250%2b_y=550%2%2
