// ��������/������ ������� ������������ ����
function sw(id){
var img=document.getElementById("menu_img_"+id);
var div=document.getElementById("menu_div_"+id);
	if(img && div){
		if(div.style.display=="none"){
		div.style.display="block"
		img.src="http://www.mnepu.ru/m.gif"
		}else{
		div.style.display="none";
		img.src="http://www.mnepu.ru/p.gif"
		}
	}
return false
}

// ����� ��������� �������
function findPosY(obj){
var curtop=0;
	if(obj.offsetParent){
		while(1){
		curtop+=obj.offsetTop;
			if(!obj.offsetParent){
			break;
			}
		obj=obj.offsetParent;
		}
	}else if (obj.y){
	curtop+=obj.y;
	}
return curtop;
}

// ������ - ����� ���������
function promoViewDown(){
document.getElementById("layoutText").style.display="block"
promoCycleViewDown()
}

function promoCycleViewDown(){
var h=document.compatMode=='CSS1Compat' && !window.opera?document.documentElement.clientHeight:document.body.clientHeight;
h=h+document.getElementById("layout").scrollTop-50
var e=document.getElementById("promoDiv")
	if(e){
	var i=findPosY(e)
		if(i<h){
		var step=(h-i)/10
			if(step<10)step=10
		i+=step
			if(i>h)i=h
		e.style.top=i+"px"
			if(i<h){
			setTimeout("promoViewDown()",3)
			return true
			}
		}
	e.style.display="none"
	document.getElementById("fixed").style.display="block"
	}
}

// �������� - ����� ���������
function promoViewTop(){
var h=document.compatMode=='CSS1Compat' && !window.opera?document.documentElement.clientHeight:document.body.clientHeight;
e=document.getElementById("promoDiv")
e.style.top=(h-50+document.getElementById("layout").scrollTop)+"px"
e.style.display="block"
e.style.height=(h+document.getElementById("layout").scrollTop-17)+"px"
document.getElementById("fixed").style.display="none"
promoCycleViewTop()
}

function promoCycleViewTop(){
var e=document.getElementById("promoDiv");
var top=document.getElementById("layout").scrollTop
	if(e){
	var i=findPosY(e)
		if(i>top){
		var step=(i-top)/10
			if(step<10)step=10
			i-=step
			if(i<=top)i=top
		e.style.top=i+"px"
			if(i>top){
			setTimeout("promoCycleViewTop()",3)
			return true
			}
		}
	document.getElementById("layoutText").style.display="none"
	}
}