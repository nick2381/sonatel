
function main_menu_init() {
	var ua = navigator.userAgent.toLowerCase();
	var is_ie = (ua.indexOf('msie') > -1);

	if(is_ie) {
		var $page = $('#page');
		var $footer = $('#footer');
	}

	$('div.group-items div.short a').hover(
		function(){
			$('div.main-menu div.hidden').fadeOut(400);
			$(this).parents('div.group-items').find('div.hidden').fadeIn(300);
			if(is_ie) {
				$page.css('z-index','1');
				$footer.css('z-index','0');
			}
		},
		function(){
		}
	);
	$('div.main-menu div.hidden').hover(
		null,
		function(){
			$(this).fadeOut(400);
			if(is_ie) {
				$page.css('z-index','0');
				$footer.css('z-index','1');
			}
		}
	);
	$('div.main-menu').hover(
		null,
		function(){
			$('div.main-menu div.hidden').fadeOut(400);
			if(is_ie) {
				$page.css('z-index','0');
				$footer.css('z-index','1');
			}
		}
	);
}

$(document).ready(function() {
main_menu_init();
});
